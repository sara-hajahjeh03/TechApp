package com.example.tech_app_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
