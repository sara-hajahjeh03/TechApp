// ignore_for_file: deprecated_member_use

import 'dart:io';

import 'package:permission_handler/permission_handler.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/widgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

void navigate(context, navigateTo, bool inableBack) {
  Navigator.pushAndRemoveUntil(
    context,
    PageRouteBuilder(
      pageBuilder: (context, animation1, animation2) => navigateTo,
      transitionDuration: Duration.zero,
      reverseTransitionDuration: Duration.zero,
    ),
    (route) => inableBack, //if you want to disable back feature set to false
  );
}

class UserSharedPref {
  static late SharedPreferences _prefs;

  static const _keyUsername = 'username';
  static const _keyEmail = 'email';
  static const _keyPicURL = 'picURL';
  static const _introScreen = 'introScreen';
  static const _userlogin = 'userLogin';

  static Future init() async => _prefs = await SharedPreferences.getInstance();

  static Future<bool?> setIntroScreen(bool done) async =>
      await _prefs.setBool(_introScreen, done);

  static getIntroScreen() => _prefs.getBool(_introScreen);

  static Future<bool?> setUserLogin(bool done) async =>
      await _prefs.setBool(_userlogin, done);

  static getUserLogin() => _prefs.getBool(_userlogin);

  static Future setUsername(String username) async =>
      await _prefs.setString(_keyUsername, username);

  static Future setUserEmail(String email) async =>
      await _prefs.setString(_keyEmail, email);

  static Future setProfilePic(String picURL) async =>
      await _prefs.setString(_keyPicURL, picURL);

  static String? getUsername() => _prefs.getString(_keyUsername);
  static String? getUserEmail() => _prefs.getString(_keyEmail);
  static String? getProfilePic() => _prefs.getString(_keyPicURL);
}

Future<void> refreshIdToken() async {
  final auth = FirebaseAuth.instance;
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  if (auth.currentUser != null) {
    final token = await auth.currentUser!.getIdToken(true);
    await firebaseFirestore
        .collection('users')
        .doc(auth.currentUser!.uid)
        .update({
      'token': token,
    });
  }
}

class PermissionHandler {
  static Future<bool> askCameraPermission() async {
    final PermissionStatus permissionStatus = await Permission.camera.request();
    return permissionStatus == PermissionStatus.granted;
  }

  static Future<bool> askGalleryPermission() async {
    final PermissionStatus permissionStatus =
        await Permission.mediaLibrary.request();
    return permissionStatus == PermissionStatus.granted;
  }

  static Future<bool> askLocationPermission() async {
    final PermissionStatus permissionStatus =
        await Permission.locationWhenInUse.request();
    return permissionStatus == PermissionStatus.granted;
  }

  static Future<bool> askMicrophonePermission() async {
    final PermissionStatus permissionStatus =
        await Permission.microphone.request();
    return permissionStatus == PermissionStatus.granted;
  }

  static Future<bool> askPhoneCallPermission() async {
    final PermissionStatus permissionStatus = await Permission.phone.request();
    return permissionStatus == PermissionStatus.granted;
  }
}

class ImageSelector {
  static Future<List<XFile>> selectImages() async {
    final ImagePicker picker = ImagePicker();
    final List<XFile>? selectedImages =
        await picker.pickMultiImage(imageQuality: 80);
    return selectedImages ?? [];
  }

  static Future<File?> takePhoto() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.camera);

    if (pickedFile == null) {
      return null;
    }

    return File(pickedFile.path);
  }
}
