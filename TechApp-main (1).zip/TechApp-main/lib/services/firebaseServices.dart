import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

// import 'package:cloud_firestore/cloud_firestore.dart';
Future<void> createChatRoom(String senderUid, String receiverUid,
    String message, String sentToName, String? senderName) async {
  final CollectionReference<Map<String, dynamic>> chatRoomCollection =
      _firestore.collection('chatRoom');

  final String chatRoomId = "${senderUid}_${receiverUid}";
  final DocumentReference<Map<String, dynamic>> chatRoomDocRef =
      chatRoomCollection.doc(chatRoomId);

  final DocumentSnapshot<Map<String, dynamic>> chatRoomSnapshot =
      await chatRoomDocRef.get();

  if (!chatRoomSnapshot.exists) {
    final Map<String, dynamic> chatRoomData = <String, dynamic>{
      'chatRoomId': chatRoomId,
      'users': [senderUid, receiverUid],
      'sentToName': sentToName,
      'senderName': senderName,
      'lastMessage': message,
      'lastMessageTime': DateTime.now(),
    };

    await chatRoomDocRef.set(chatRoomData);
  }

  final Map<String, dynamic> messageData = <String, dynamic>{
    'message': message,
    'sentBy': senderUid,
    'sentTime': DateTime.now(),
  };
  final CollectionReference<Map<String, dynamic>> chatSubcollection =
      chatRoomDocRef.collection('chat');
  final String messageId = chatSubcollection.doc().id;
  final DocumentReference<Map<String, dynamic>> messageDocRef =
      chatSubcollection.doc(messageId);

  await messageDocRef.set(messageData);

  // Update the lastMessage and lastMessageTime fields in the chat room document
  await chatRoomDocRef.update({
    'lastMessage': message,
    'lastMessageTime': DateTime.now(),
  });
}

Future<void> sendMessage(String chatRoomId, String message, String senderUid,
    String messageType) async {
  final CollectionReference<Map<String, dynamic>> chatRoomCollection =
      _firestore.collection('chatRoom');
  final DocumentReference<Map<String, dynamic>> chatRoomDocRef =
      chatRoomCollection.doc(chatRoomId);

  final CollectionReference<Map<String, dynamic>> chatSubcollection =
      chatRoomDocRef.collection('chat');

  final Map<String, dynamic> messageData = <String, dynamic>{
    'message': message,
    'messageType': messageType,
    'sentBy': senderUid,
    'sentTime': DateTime.now(),
  };

  final String messageId = chatSubcollection.doc().id;
  final DocumentReference<Map<String, dynamic>> messageDocRef =
      chatSubcollection.doc(messageId);

  await messageDocRef.set(messageData);

  // Update the lastMessage and lastMessageTime fields in the chat room document
  await chatRoomDocRef.update({
    'lastMessage': messageType == 'text' ? message : '[image]',
    'lastMessageTime': DateTime.now(),
  });
}

Future<String> getImageURL(String name) async {
  final FirebaseStorage storage = FirebaseStorage.instance;
  final Reference storageReference = storage.ref().child('chatImages');
  print(
      "asdklmasdas dasda sdkla sd askd aksd a sdka sdka sda dkja skd asd ajksdkjasd");
  var str = await storageReference.getDownloadURL();
  print(str);

  return str;
}

// sendImageMessage(String url, String chatRoomId, String senderUid) async {
//   sendMessage(chatRoomId, url, _auth.currentUser!.uid);
// }

Future<String> uploadImageToFirebase(
    File imagePath, String chatRoomId, String senderUid) async {
  try {
    final FirebaseStorage storage = FirebaseStorage.instance;
    final Reference storageReference = storage.ref().child('chatImages');

    // Create a unique file name for the image
    final String fileName = DateTime.now().millisecondsSinceEpoch.toString();
    print(
        "objectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobjectobject");

    storageReference.putFile(imagePath).snapshotEvents.listen((event) async {
      switch (event.state) {
        case TaskState.running:
          break;

        case TaskState.paused:
          break;

        case TaskState.canceled:
          break;
        case TaskState.error:
          break;

        case TaskState.success:
          String imageUrl = await getImageURL(fileName);

          sendMessage(chatRoomId, imageUrl, _auth.currentUser!.uid, 'image');
      }
    });
  } catch (e) {
    print("There is an error in uploading image: $e");
  }
  return "";
}

Stream<QuerySnapshot<Map<String, dynamic>>> getMessageStream(
    String chatRoomId) {
  if (chatRoomId.isEmpty) {
    // Return a default empty stream if the chatRoomId is not provided
    return Stream<QuerySnapshot<Map<String, dynamic>>>.empty();
  }

  final CollectionReference<Map<String, dynamic>> messageCollection =
      FirebaseFirestore.instance.collection('chatRoom');

  final DocumentReference<Map<String, dynamic>> senderDocRef =
      messageCollection.doc(chatRoomId);

  final CollectionReference<Map<String, dynamic>> subcollection =
      senderDocRef.collection("chat");

  return subcollection.orderBy('sentTime', descending: true).snapshots();
}

Future<List<dynamic>> getChatWithList(String currentUserUid) async {
  final CollectionReference<Map<String, dynamic>> chatRoomCollection =
      _firestore.collection('chatRoom');

  final QuerySnapshot<Map<String, dynamic>> querySnapshot =
      await chatRoomCollection
          .where('users', arrayContains: currentUserUid)
          .get();

  final List<Map<String, dynamic>> chatRoomData = querySnapshot.docs.map((doc) {
    final String documentId = doc.id;
    final Map<String, dynamic> data = doc.data();
    data['documentId'] = documentId; // Add the document ID to the data
    return data;
  }).toList();

  return chatRoomData;
}

    //   final Reference imageReference = storageReference.child(fileName);

    //   // Upload the image file to Firebase Cloud Storage
    //   final UploadTask uploadTask = imageReference.putFile(imagePath);
    //   final TaskSnapshot storageSnapshot =
    //       await uploadTask.whenComplete(() => null);

    //   // Get the download URL of the uploaded image
    //   final String downloadUrl = await storageSnapshot.ref.getDownloadURL();

    //   return downloadUrl;
    // } catch (error) {
    //   print('Error uploading image to Firebase: $error');
    //   return null;