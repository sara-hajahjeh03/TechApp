// ignore_for_file: depend_on_referenced_packages
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tech_app_v1/SharedScreens/choice_Screen.dart';
import 'package:tech_app_v1/UserScreens/home_Screen.dart';
import 'package:tech_app_v1/SharedScreens/introductionScreen/intro_Screens.dart';
import 'package:tech_app_v1/UserScreens/signIn_screen.dart';
import 'package:tech_app_v1/Utilities/StateMangmentProviders/uplaodPicProvider.dart';
import 'package:tech_app_v1/adminPanel/Screens/AdminPanelProviderSignUp.dart';
import 'package:tech_app_v1/services/userServices.dart';

bool show = true;
bool loggedIn = false;
Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await UserSharedPref.init();
  show = UserSharedPref.getIntroScreen() ?? true;
  loggedIn = UserSharedPref.getUserLogin() ?? false;

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UploadPicProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: show
          ? const IntroScreen()
          : loggedIn
              ? home_Screen()
              : choice_Screen(),
    );
  }
}
