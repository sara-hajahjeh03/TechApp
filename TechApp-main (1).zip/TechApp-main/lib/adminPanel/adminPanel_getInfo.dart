import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import '../providerModel/provider_models.dart';

final CollectionReference adminPanel =
    FirebaseFirestore.instance.collection('Admin_Approval_Provider_SignUp');

class adminPanel_Get_Info extends StatefulWidget {
  final _auth = FirebaseAuth.instance;
  final String documentId;
  adminPanel_Get_Info({Key? key, required this.documentId}) : super(key: key);

  @override
  State<adminPanel_Get_Info> createState() => _adminPanel_Get_InfoState();
}

class _adminPanel_Get_InfoState extends State<adminPanel_Get_Info> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    return FutureBuilder<DocumentSnapshot>(
      future: adminPanel.doc(widget.documentId).get(),
      builder: ((context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          Map<String, dynamic> data =
              snapshot.data!.data() as Map<String, dynamic>;
          var occupationEdittingController = data['Occupation'];
          var cityEditingController = data['City'];
          var aboutEditingController = data['About'];
          var profilePicController = data['profilePic'];
          var phoneNumberController = data['phoneNumber'];
          var fullnameEditingController = data['FullName'];
          var emailEditingController = data['email'];
          var uidEditingController = data['uid'];
          var subscriptionEdittingController = data['subscriptionType'];
          var idNumber = data['idNumber'];

          admin_approval() async {
            UserModelProvider userModel = UserModelProvider();
            userModel.Occupation = occupationEdittingController;
            userModel.email = emailEditingController;
            userModel.uid = uidEditingController;
            userModel.FullName = fullnameEditingController;
            userModel.city = cityEditingController;
            userModel.About = aboutEditingController;
            userModel.profilePic = profilePicController;
            userModel.phoneNumber = phoneNumberController;
            userModel.subscriptionType = subscriptionEdittingController;
            userModel.idNumber = idNumber;

            if (occupationEdittingController == 'Electrician' ||
                occupationEdittingController == 'كهربائي') {
              await firebaseFirestore
                  .collection("Provider_Electrician")
                  .doc(widget.documentId)
                  .set(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_Provider_SignUp")
                  .doc(widget.documentId)
                  .delete();
            }
            if (occupationEdittingController == "Carpenter" ||
                occupationEdittingController == "نجار") {
              await firebaseFirestore
                  .collection("Provider_Carpenter")
                  .doc(widget.documentId)
                  .set(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_Provider_SignUp")
                  .doc(widget.documentId)
                  .delete();
            }
            if (occupationEdittingController == "Plumber" ||
                occupationEdittingController == "سباك") {
              await firebaseFirestore
                  .collection("Provider_Plumber")
                  .doc(widget.documentId)
                  .set(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_Provider_SignUp")
                  .doc(widget.documentId)
                  .delete();
            }
            if (occupationEdittingController == "Smith" ||
                occupationEdittingController == "حداد") {
              await firebaseFirestore
                  .collection("Provider_ Smith")
                  .doc(widget.documentId)
                  .set(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_Provider_SignUp")
                  .doc(widget.documentId)
                  .delete();
            }
            if (occupationEdittingController == "painter" ||
                occupationEdittingController == "اعمال الدهان") {
              await firebaseFirestore
                  .collection("Provider_ painter")
                  .doc(widget.documentId)
                  .set(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_Provider_SignUp")
                  .doc(widget.documentId)
                  .delete();
            }
            if (occupationEdittingController == "carWash" ||
                occupationEdittingController == "توصيل البنزين") {
              await firebaseFirestore
                  .collection("Provider_ carWash")
                  .doc(widget.documentId)
                  .set(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_Provider_SignUp")
                  .doc(widget.documentId)
                  .delete();
            }
            if (occupationEdittingController == "Mechanic" ||
                occupationEdittingController == "ميكانيكي") {
              await firebaseFirestore
                  .collection("Provider_ Mechanic")
                  .doc(widget.documentId)
                  .set(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_Provider_SignUp")
                  .doc(widget.documentId)
                  .delete();
            }
            if (occupationEdittingController == "oilDelivery" ||
                occupationEdittingController == "توصيل البنزين") {
              await firebaseFirestore
                  .collection("Provider_ oilDelivery")
                  .doc(widget.documentId)
                  .set(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_Provider_SignUp")
                  .doc(widget.documentId)
                  .delete();
            }
          }

          return PhysicalModel(
            color: Colors.white,
            elevation: 1,
            borderRadius: const BorderRadius.all(Radius.circular(16)),
            child: Container(
              height: 0.53 * h,
              width: 0.9227 * w,
              decoration: const BoxDecoration(
                  color: SystemColors.whiteBackgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(16))),
              child: Stack(
                children: [
                  Padding(
                    padding: EdgeInsets.only(right: 0.0386 * w, top: 0.03 * h),
                    child: const Align(
                      alignment: Alignment.topRight,
                      child: CircleAvatar(
                        radius: 43,
                        backgroundColor: Colors.grey,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.0324 * h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          '${data['FullName']}',
                          style: GoogleFonts.almarai(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: SystemColors.textColorBlack),
                        ),
                        SizedBox(width: 0.019 * w),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(width: 0.256 * w),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.0598 * h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          '${data['Occupation']}',
                          style: GoogleFonts.almarai(
                              fontSize: SystemSize.textSize14,
                              fontWeight: FontWeight.w400,
                              color: const Color(0xFF7D7D7D),
                              wordSpacing: 1),
                        ),
                        SizedBox(
                          width: 0.273 * w,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.0931 * h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          'المحافظة: ${data['City']}',
                          style: GoogleFonts.almarai(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: SystemColors.textColorBlack),
                        ),
                        SizedBox(
                          width: 0.019 * w,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset('assets/locationIcon.png'),
                            SizedBox(
                              width: 0.256 * w,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.15 * h, left: 0.02 * w),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'location: ${data['location']}',
                        textDirection: TextDirection.rtl,
                        style: GoogleFonts.almarai(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: SystemColors.textColorBlack),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.20 * h, left: 0.02 * w),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'UID: ${data['uid']}',
                        textDirection: TextDirection.rtl,
                        style: GoogleFonts.almarai(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: SystemColors.textColorBlack),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.25 * h, left: 0.02 * w),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'Email: ${data['email']}',
                        textDirection: TextDirection.rtl,
                        style: GoogleFonts.almarai(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: SystemColors.textColorBlack),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.30 * h, left: 0.02 * w),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'idNumber: ${data['idNumber']}',
                        textDirection: TextDirection.rtl,
                        style: GoogleFonts.almarai(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: SystemColors.textColorBlack),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.35 * h, left: 0.02 * w),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'phoneNumber: ${data['phoneNumber']}',
                        textDirection: TextDirection.rtl,
                        style: GoogleFonts.almarai(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: SystemColors.textColorBlack),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.40 * h, left: 0.02 * w),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'subscriptionType: ${data['subscriptionType']}',
                        textDirection: TextDirection.rtl,
                        style: GoogleFonts.almarai(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: SystemColors.textColorBlack),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 0.45 * h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        InkWell(
                          onTap: () {
                            admin_approval();
                          },
                          child: Button_widget(
                            buttonWidth: 0.4 * w,
                            buttonText: 'موافقة',
                            activeButton1: true,
                            activeButtonColor: SystemColors.mainColor,
                            activeTextColor: SystemColors.whiteBackgroundColor,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            firebaseFirestore
                                .collection("Admin_Approval_Provider_SignUp")
                                .doc(widget.documentId)
                                .delete();
                          },
                          child: Button_widget(
                            buttonWidth: 0.4 * w,
                            buttonText: 'رفض',
                            activeButton1: true,
                            activeButtonColor: SystemColors.mainColor,
                            activeTextColor: SystemColors.whiteBackgroundColor,
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          );
        }
        return Container(
          height: 0.53 * h,
          width: 0.9227 * w,
          color: Colors.white,
          child: const Center(
            child: CircularProgressIndicator(color: SystemColors.mainColor),
          ),
        );
      }),
    );
  }
}
