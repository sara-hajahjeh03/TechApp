import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/adminPanel/Screens/AdminPanelProviderSignUp.dart';
import 'package:tech_app_v1/adminPanel/Screens/AdminPanelUserOrders.dart';
import 'package:tech_app_v1/services/userServices.dart';

class AdminPanelHome extends StatelessWidget {
  const AdminPanelHome({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return SafeArea(
        child: Scaffold(
          body: Column(
            children: [
              AppBar_Widget(
                icon: false,
                titleText: 'Admin Panel',
                appBarheight: SystemSize.appBarheight.h,
              ),
              SizedBox(
                height: 20.h,
              ),
              Button_widget(
                Function: () {
                  navigate(context, AdminPanelProviderSignUp(), true);
                },
                buttonWidth: 90.w,
                buttonText: "Provider SignUp",
                activeButton1: true,
                activeButtonColor: SystemColors.mainColor,
                activeTextColor: SystemColors.whiteBackgroundColor,
              ),
              SizedBox(
                height: 3.h,
              ),
              Button_widget(
                Function: () {
                  navigate(context, AdminPanelUserOrders(), true);
                },
                buttonWidth: 90.w,
                buttonText: "User Orders",
                activeButton1: true,
                activeButtonColor: SystemColors.mainColor,
                activeTextColor: SystemColors.whiteBackgroundColor,
              )
            ],
          ),
        ),
      );
    });
  }
}
