import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/adminPanel/Services/adminPanel_GetUserOrders.dart';

class AdminPanelUserOrders extends StatefulWidget {
  AdminPanelUserOrders({Key? key}) : super(key: key);

  @override
  State<AdminPanelUserOrders> createState() => _AdminPanelUserOrdersState();
}

class _AdminPanelUserOrdersState extends State<AdminPanelUserOrders> {
  // document IDs
  List<String> docIDs = [];
// get docIDS
  Future getDocId() async {
    await FirebaseFirestore.instance
        .collection('Admin_Approval_UserOrders')
        .get()
        .then(
          (snapshot) => snapshot.docs.forEach((document) {
            docIDs.add(document.reference.id);
          }),
        );
  }

  late Future<dynamic> dataFuture;
  @override
  void initState() {
    super.initState();
    dataFuture = getDocId();
  }

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return SafeArea(
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            toolbarHeight: MediaQuery.of(context).size.height * 0.077,
            title: Text(
              'User Orders',
              style: GoogleFonts.tajawal(
                  fontSize: SystemSize.smallTextSize,
                  fontWeight: FontWeight.w500,
                  color: SystemColors.textColorBlack),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: () {
                  docIDs.clear();
                  setState(() {
                    dataFuture = getDocId();
                  });
                },
                color: Colors.black,
              )
            ],
            centerTitle: true,
            backgroundColor: SystemColors.whiteBackgroundColor,
          ),
          body: Container(
            color: SystemColors.whiteBackgroundColor,
            child: Column(
              children: [
                Expanded(
                    child: FutureBuilder(
                        future: dataFuture,
                        builder: (context, snapshot) {
                          return ListView.builder(
                              itemCount: docIDs.length,
                              itemBuilder: (context, index) {
                                return ListTile(
                                  title: adminPanel_Get_UserOrders(
                                      documentId: docIDs[index]),
                                );
                              });
                        }))
              ],
            ),
          ),
        ),
      );
    });
  }
}
