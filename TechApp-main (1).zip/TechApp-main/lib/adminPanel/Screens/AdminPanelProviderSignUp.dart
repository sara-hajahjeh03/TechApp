// ignore_for_file: camel_case_types, prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/adminPanel/adminPanel_getInfo.dart';

class AdminPanelProviderSignUp extends StatefulWidget {
  const AdminPanelProviderSignUp({Key? key}) : super(key: key);

  @override
  State<AdminPanelProviderSignUp> createState() =>
      _AdminPanelProviderSignUpState();
}

class _AdminPanelProviderSignUpState extends State<AdminPanelProviderSignUp> {
  // document IDs
  List<String> docIDs = [];
// get docIDS
  Future getDocId() async {
    await FirebaseFirestore.instance
        .collection('Admin_Approval_Provider_SignUp')
        .get()
        .then(
          (snapshot) => snapshot.docs.forEach((document) {
            docIDs.add(document.reference.id);
          }),
        );
  }

  late Future<dynamic> dataFuture;
  @override
  void initState() {
    super.initState();
    dataFuture = getDocId();
  }

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return SafeArea(
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            toolbarHeight: MediaQuery.of(context).size.height * 0.077,
            title: Text(
              'Provider SignUp',
              style: GoogleFonts.tajawal(
                  fontSize: SystemSize.smallTextSize,
                  fontWeight: FontWeight.w500,
                  color: SystemColors.textColorBlack),
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.refresh),
                onPressed: () {
                  docIDs.clear();
                  setState(() {
                    dataFuture = getDocId();
                    
                  });
                },
                color: Colors.black,
              )
            ],
            centerTitle: true,
            backgroundColor: SystemColors.whiteBackgroundColor,
          ),
          body: Container(
            color: SystemColors.whiteBackgroundColor,
            child: Column(
              children: [
                Expanded(
                    child: FutureBuilder(
                        future: dataFuture,
                        builder: (context, snapshot) {
                          return ListView.builder(
                              itemCount: docIDs.length,
                              itemBuilder: (context, index) {
                                return ListTile(
                                  title: adminPanel_Get_Info(
                                      documentId: docIDs[index]),
                                );
                              });
                        }))
              ],
            ),
          ),
        ),
      );
    });
  }
}
