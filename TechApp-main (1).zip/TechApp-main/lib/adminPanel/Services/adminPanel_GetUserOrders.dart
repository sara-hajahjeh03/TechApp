import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/backContainer_widget.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/services/userServices.dart';
import 'package:tech_app_v1/userModel/user_models.dart';

final CollectionReference adminPanel =
    FirebaseFirestore.instance.collection('Admin_Approval_UserOrders');

class adminPanel_Get_UserOrders extends StatefulWidget {
  final _auth = FirebaseAuth.instance;
  final String documentId;
  adminPanel_Get_UserOrders({Key? key, required this.documentId})
      : super(key: key);

  @override
  State<adminPanel_Get_UserOrders> createState() =>
      _adminPanel_Get_UserOrdersState();
}

class _adminPanel_Get_UserOrdersState extends State<adminPanel_Get_UserOrders> {
  bool isRefreshing = false;

  @override
  void initState() {
    super.initState();
    isRefreshing = false;
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    return Sizer(builder: (context, orientation, deviceType) {
      return FutureBuilder<DocumentSnapshot>(
        future: adminPanel.doc(widget.documentId).get(),
        builder: ((context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done ||
              isRefreshing==true) {
            Map<String, dynamic> data =
                snapshot.data!.data() as Map<String, dynamic>;
            var aboutJob = data['aboutJob'];
            var profilePic = data['profilePic'];
            var fullName = data['FullName'];
            var email = data['email'];
            var uid = data['uid'];
            var jobLocation = data['jobLocation'];
            List<dynamic> orderImages = [];
            orderImages.addAll(data['orderPics']);

            admin_approval() async {
              UserModel userModel = UserModel();
              userModel.email = email;
              userModel.uid = uid;
              userModel.FullName = fullName;
              userModel.aboutJob = aboutJob;
              userModel.profilePic = profilePic;
              userModel.orderPics = orderImages.cast<String>();
              userModel.jobLocation = jobLocation;

              await firebaseFirestore
                  .collection("userOrders")
                  .add(userModel.toMap());
              firebaseFirestore
                  .collection("Admin_Approval_UserOrders")
                  .doc(widget.documentId)
                  .delete();
            }

            return PhysicalModel(
              color: Colors.white,
              elevation: 1,
              borderRadius: const BorderRadius.all(Radius.circular(16)),
              child: Container(
                height: 0.73 * h,
                width: 0.9227 * w,
                decoration: const BoxDecoration(
                    color: SystemColors.whiteBackgroundColor,
                    borderRadius: BorderRadius.all(Radius.circular(16))),
                child: Stack(
                  children: [
                    Padding(
                      padding:
                          EdgeInsets.only(right: 0.0386 * w, top: 0.03 * h),
                      child: const Align(
                        alignment: Alignment.topRight,
                        child: CircleAvatar(
                          radius: 43,
                          backgroundColor: Colors.grey,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 0.0324 * h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            '${data['FullName']}',
                            style: GoogleFonts.almarai(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: SystemColors.textColorBlack),
                          ),
                          SizedBox(width: 0.019 * w),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(width: 0.256 * w),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 0.15 * h, left: 0.02 * w),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'location: $jobLocation',
                          textDirection: TextDirection.rtl,
                          style: GoogleFonts.almarai(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: SystemColors.textColorBlack),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 0.20 * h, left: 0.02 * w),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'UID: ${data['uid']}',
                          textDirection: TextDirection.rtl,
                          style: GoogleFonts.almarai(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: SystemColors.textColorBlack),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 0.25 * h, left: 0.02 * w),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'Email: ${data['email']}',
                          textDirection: TextDirection.rtl,
                          style: GoogleFonts.almarai(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: SystemColors.textColorBlack),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 0.40 * h, left: 0.02 * w),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: backContainer_widget(
                          height: 19.96.h,
                          width: 92.27.w,
                          color: SystemColors.whiteBackgroundColor,
                          DottedBorderStrokePattern: 5,
                          DottedBorderColor: SystemColors.mainColor,
                          radius: 16,
                          DottedBorderStrokeWidth: 1,
                          child: Padding(
                            padding: EdgeInsets.all(2.0.w),
                            child: GridView.builder(
                              itemCount: orderImages.length,
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 3,
                                      mainAxisSpacing: 0.01 * h,
                                      crossAxisSpacing: 0.01 * h),
                              itemBuilder: (BuildContext context, int index) {
                                return ClipRRect(
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(8)),
                                  child: Image.network('${orderImages[index]}',
                                      fit: BoxFit.cover),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 0.28 * h),
                      child: SizedBox(
                        width: 90.w,
                        child: Text(
                          'وصف الخدمة :- $aboutJob',
                          textDirection: TextDirection.rtl,
                          style: GoogleFonts.almarai(
                              fontSize: SystemSize.textSize14,
                              fontWeight: FontWeight.w400,
                              color: const Color(0xFF7D7D7D),
                              wordSpacing: 1),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 2.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 0.65 * h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          InkWell(
                            onTap: () {
                              admin_approval();
                              setState(() {
                                isRefreshing = true;
                              });
                            },
                            child: Button_widget(
                              buttonWidth: 0.4 * w,
                              buttonText: 'موافقة',
                              activeButton1: true,
                              activeButtonColor: SystemColors.mainColor,
                              activeTextColor: SystemColors.whiteBackgroundColor,
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              firebaseFirestore
                                  .collection("Admin_Approval_UserOrders")
                                  .doc(widget.documentId)
                                  .delete();
                                  
                            },
                            child: Button_widget(
                              buttonWidth: 0.4 * w,
                              buttonText: 'رفض',
                              activeButton1: true,
                              activeButtonColor: SystemColors.mainColor,
                              activeTextColor: SystemColors.whiteBackgroundColor,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            );
          }
          return Container(
            height: 0.53 * h,
            width: 0.9227 * w,
            color: Colors.white,
            child: const Center(
              child: CircularProgressIndicator(color: SystemColors.mainColor),
            ),
          );
        }),
      );
    });
  }
}
