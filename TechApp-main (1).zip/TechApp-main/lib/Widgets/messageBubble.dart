import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class MessageBubble extends StatelessWidget {
  final String? message;
  final bool isMe;
  final String time;
  final bool? isImage;
  final String? imagePath;
  final File? imageFilePath;
  MessageBubble(
      {this.message,
      required this.isMe,
      required this.time,
      this.isImage = false,
      this.imagePath =
          "https://firebasestorage.googleapis.com/v0/b/techappfinal.appspot.com/o/chatImages%2F1684258443807?alt=media&token=e9456634-4764-424e-8c22-266531d8394f",
      this.imageFilePath});

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return LayoutBuilder(builder: (context, constraints) {
      return Stack(
        children: [
          Row(
            mainAxisAlignment:
                isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
            children: [
              Container(
                constraints: BoxConstraints(maxWidth: w * 0.748792271),
                decoration: BoxDecoration(
                  color: isMe
                      ? SystemColors.mainColor
                      : SystemColors.messageIsNotMeColor,
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(16),
                    topRight: const Radius.circular(16),
                    bottomLeft: isMe
                        ? const Radius.circular(16)
                        : const Radius.circular(0),
                    bottomRight: isMe
                        ? const Radius.circular(0)
                        : const Radius.circular(16),
                  ),
                ),
                padding: const EdgeInsets.symmetric(
                  vertical: 10,
                  horizontal: 16,
                ),
                margin: EdgeInsets.only(
                    top: h * 0.008928571, bottom: h * 0.008928571),
                child: Column(
                  crossAxisAlignment:
                      isMe ? CrossAxisAlignment.end : CrossAxisAlignment.end,
                  children: [
                    isImage!
                        ? Container(
                            decoration: const BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(16))),
                            height: h * 0.3,
                            width: w * 0.748792271,
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(16)),
                              child: CachedNetworkImage(
                                fadeInDuration: const Duration(microseconds: 0),
                                // useOldImageOnUrlChange: true,
                                fadeOutDuration:
                                    const Duration(microseconds: 0),
                                placeholder: (context, url) =>
                                    imageFilePath != null
                                        ? Center(
                                            child: Image.file(imageFilePath!),
                                          )
                                        : Center(
                                            child: CircularProgressIndicator()),
                                imageUrl: imagePath!,
                                fit: BoxFit.cover,
                                placeholderFadeInDuration:
                                    const Duration(microseconds: 0),
                                height: h * 0.3,
                                width: w * 0.748792271,
                              ),
                            ),
                          )
                        : Text(message!,
                            textAlign: TextAlign.right,
                            style: GoogleFonts.almarai(
                                fontSize: SystemSize.textSize14,
                                fontWeight: FontWeight.w400,
                                color: isMe
                                    ? SystemColors.whiteBackgroundColor
                                    : SystemColors.textColorBlack,
                                wordSpacing: 1)),
                    SizedBox(height: h * 0.009),
                    Text(
                      time,
                      style: const TextStyle(
                        color: SystemColors.greyColor,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      );
    });
  }
}
