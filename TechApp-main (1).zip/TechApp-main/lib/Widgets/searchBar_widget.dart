import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class SearchBar extends StatelessWidget {
  final double? barHeight;
  final double? barwidth;
  final String hintText;

  const SearchBar(
      {Key? key, this.barHeight, this.barwidth, required this.hintText})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SizedBox(
      width: w * 0.9227,
      child: PhysicalModel(
        shadowColor: SystemColors.whiteBackgroundColor,
        color: SystemColors.whiteBackgroundColor,
        borderRadius: const BorderRadius.all(Radius.circular(10)),
        elevation: 1,
        child: Container(
          margin: EdgeInsets.only(left: 0.03864 * w, right: 0.03864 * w),
          height: 45,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: SystemColors.whiteBackgroundColor),
          child: TextField(
            textAlign: TextAlign.right,
            onChanged: (value) {},
            decoration: InputDecoration(
              hintTextDirection: TextDirection.rtl,
              suffixIcon: Image.asset('assets/searchIcon.png'),
              hintText: hintText,
              hintStyle: GoogleFonts.almarai(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF7D7D7D),
                  wordSpacing: 1),
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
            ),
          ),
        ),
      ),
    );
  }
}
