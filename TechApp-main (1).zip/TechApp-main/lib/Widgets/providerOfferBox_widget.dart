import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:tech_app_v1/UserScreens/viewProviderProfile.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class ProviderOfferBox_widget extends StatefulWidget {
  const ProviderOfferBox_widget({
    Key? key,
  }) : super(key: key);

  @override
  State<ProviderOfferBox_widget> createState() =>
      _ProviderOfferBox_widgetState();
}

class _ProviderOfferBox_widgetState extends State<ProviderOfferBox_widget> {
  final _controller = PageController();
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Column(children: [
      SizedBox(
        height: 0.1496 * h,
        width: 1 * w,
        child: PageView(
          controller: _controller,
          children: [
            providerOfferBox(),
            providerOfferBox(),
            providerOfferBox(),
            providerOfferBox(),
            providerOfferBox(),
          ],
        ),
      ),
      SizedBox(
        height: 0.0179 * h,
      ),
      SmoothPageIndicator(
        controller: _controller,
        count: 5,
        effect: SlideEffect(
            dotHeight: 0.0112 * h,
            dotWidth: 0.0242 * w,
            dotColor: SystemColors.greyColor,
            activeDotColor: SystemColors.mainColor),
      )
    ]);
  }

  Widget providerOfferBox() {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 0.0386 * w),
      decoration: const BoxDecoration(
          color: Color(0xFFF4F4F4),
          borderRadius: BorderRadius.all(Radius.circular(16))),
      child: Stack(
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: Container(
              decoration: const BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.all(Radius.circular(16))),
              height: 0.1473 * h,
              width: 0.2488 * w,
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(top: 0.0167 * h),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Text(
                    'محمد العطار',
                    style: GoogleFonts.almarai(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: SystemColors.textColorBlack,
                        wordSpacing: 1),
                  ),
                ),
              ),
              SizedBox(
                width: 0.2681 * w,
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(top: 0.04576 * h),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Text(
                    'المهنه : كهربائي',
                    style: GoogleFonts.almarai(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: SystemColors.textColorBlack,
                        wordSpacing: 1),
                  ),
                ),
              ),
              SizedBox(
                width: 0.2681 * w,
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(top: 0.0748 * h),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: SizedBox(
                    height: 0.058 * h,
                    width: 0.391 * w,
                    child: Text(
                      'يمكننى ان اقوم بكل اعمالك الكهربائيه فى منزلك باسرع وقت واسهل وائمن طريقه وبافضل سعر ممكن ......',
                      textDirection: TextDirection.rtl,
                      style: GoogleFonts.almarai(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: SystemColors.textColorBlack,
                          wordSpacing: 1),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 0.2681 * w,
              ),
            ],
          ),
          Column(
            children: [
              SizedBox(
                height: 0.0682 * h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 0.0386 * w),
                child: InkWell(
                  onTap: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation1, animation2) =>
                             ViewProviderProfile(),
                        transitionDuration: Duration.zero,
                        reverseTransitionDuration: Duration.zero,
                      ),
                      (route) =>
                          true, //if you want to disable back feature set to false
                    );
                  },
                  child: Container(
                    height: 0.05 * h,
                    width: 0.191 * w,
                    decoration: const BoxDecoration(
                        color: SystemColors.mainColor,
                        borderRadius: BorderRadius.all(Radius.circular(10))),
                    child: Center(
                      child: Text(
                        'تواصل',
                        style: GoogleFonts.almarai(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: SystemColors.whiteBackgroundColor,
                            wordSpacing: 1),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Column(
            children: [
              SizedBox(
                height: 0.0213 * h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 0.082 * w),
                child: Row(
                  children: [
                    Text(
                      '4.5',
                      style: SystemFont.mainFont14W400,
                    ),
                    const Icon(
                      Icons.star,
                      color: Color(0xFFE0B315),
                    ),
                  ],
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
