import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class TextField_Widget extends StatefulWidget {
  final String Text;
  final TextEditingController? controller;
  final double fieldWidth;
  final double fieldHeight;
  final double? errorHeight;
  final double? maxHeight;
  final double? verticalContentPadding;
  final double? horizontalContentPadding;
  final String? labelText;
  final FormFieldValidator? fieldValidator;
  final double textSize;
  final dynamic keyboardType;
  final Color? textColor;
  final String? preffixIcon;
  final TextInputAction? inputAction;
  final bool? isPassword;
  final Color? textFieldColor;
  final bool? leftIcon;
  final double? elevation;
  final bool? rightIcon;
  final String? suffixIcon;
  final VoidCallback? leftIconFunction;
  final String? validateText;
  final String RegExp;
  final String? RegExpText;
  final bool? passwordIsWrong;
  final bool? itsWrong;
  final int? maxLines;

  const TextField_Widget({
    Key? key,
    required this.Text,
    this.controller,
    required this.fieldWidth,
    this.labelText,
    this.fieldValidator,
    this.fieldHeight = 0.0665,
    required this.textSize,
    this.keyboardType = TextInputType.name,
    this.errorHeight = 0.1,
    this.textColor = SystemColors.textFieldTextColor,
    this.preffixIcon = 'assets/Check.png',
    this.maxHeight,
    this.inputAction = TextInputAction.next,
    this.isPassword = false,
    this.verticalContentPadding = 50,
    this.horizontalContentPadding = 40,
    this.textFieldColor = SystemColors.lightGrey,
    this.leftIcon = true,
    this.elevation = 0,
    this.rightIcon = false,
    this.suffixIcon,
    this.leftIconFunction,
    this.validateText,
    this.RegExp = r'^.{3,}$',
    this.RegExpText = 'Wrong',
    this.passwordIsWrong = true,
    this.itsWrong = false, this.maxLines=1,
  }) : super(key: key);

  @override
  State<TextField_Widget> createState() => _TextField_WidgetState();
}

class _TextField_WidgetState extends State<TextField_Widget> {
  late double containerHeight = widget.fieldHeight;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;

    return Sizer(builder: (context, orientation, deviceType) {
      return PhysicalModel(
        color: Colors.white,
        elevation: widget.elevation!,
        borderRadius: const BorderRadius.all(Radius.circular(10)),
        child: Container(
          width: widget.fieldWidth,
          height: containerHeight,
          constraints: BoxConstraints(
              minHeight: h * widget.fieldHeight,
              maxHeight: h * widget.errorHeight!),
          child: TextFormField(
            maxLines: widget.maxLines,
            validator: (value) {
              if (value == null || value.isEmpty) {
                setState(() {
                  containerHeight = h * widget.errorHeight!;
                });
                return ('يجب تعبأة هذه الخانة');
              } else {
                setState(() {
                  containerHeight = h * widget.fieldHeight;
                });
              }
              return null;
            },
            obscureText: widget.isPassword!,
            textAlign: TextAlign.right,
            autofocus: false,
            textInputAction: widget.inputAction,
            keyboardType: widget.keyboardType,
            controller: widget.controller,
            onSaved: (value) {
              widget.controller!.text = value!;
            },
            autocorrect: true,
            decoration: InputDecoration(
                suffixIcon:
                    widget.rightIcon! ? Image.asset(widget.suffixIcon!) : null,
                isDense: true,
                filled: true,
                fillColor: widget.textFieldColor,
                prefixIcon: widget.leftIcon!
                    ? InkWell(
                        onTap: widget.leftIconFunction,
                        child: Image.asset(
                          widget.preffixIcon!,
                        ),
                      )
                    : null,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none),
                errorBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  borderSide: BorderSide(width: 1, color: Colors.grey),
                ),
                contentPadding: EdgeInsets.symmetric(
                    vertical: h / widget.verticalContentPadding!,
                    horizontal: w / widget.horizontalContentPadding!),
                hintText: widget.Text,
                hintStyle: GoogleFonts.almarai(
                  fontSize: widget.textSize,
                  fontWeight: FontWeight.w400,
                  color: widget.textColor,
                ),
                labelText: widget.labelText,
                floatingLabelBehavior: FloatingLabelBehavior.always),
          ),
        ),
      );
    });
  }
}
