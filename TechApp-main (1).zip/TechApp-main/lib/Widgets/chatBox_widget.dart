import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class ChatBoxWidget extends StatefulWidget {
  final String? name;
  final String? message;
  final String? time;
  final String? amPm;
  const ChatBoxWidget(
      {super.key, this.name, this.message, this.time, this.amPm});

  @override
  State<ChatBoxWidget> createState() => _ChatBoxWidgetState();
}

class _ChatBoxWidgetState extends State<ChatBoxWidget> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: w * 0.038647343, vertical: h * 0.017857143),
      height: h * 0.099357143,
      width: w * 0.922705314,
      decoration: const BoxDecoration(
          color: SystemColors.whiteBackgroundColor,
          borderRadius: BorderRadius.all(Radius.circular(16))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: h * 0.024508929,
                    width: w * 0.080724638,
                    child: Text(
                      textAlign: TextAlign.left,
                      widget.time!,
                      style: SystemFont.mainFont12W400,
                    ),
                  ),
                  SizedBox(
                      height: h * 0.017857143,
                      width: w * 0.038647343,
                      child: CircleAvatar(
                        backgroundColor: SystemColors.mainColor,
                        child: Center(
                            child: Text(
                          "10",
                          maxLines: 1,
                          style: GoogleFonts.almarai(
                              fontSize: 9,
                              fontWeight: FontWeight.w400,
                              color: SystemColors.whiteBackgroundColor,
                              wordSpacing: 1),
                        )),
                      )),
                ],
              ),
              SizedBox(
                height: h * 0.024508929,
                width: w * 0.090048309,
                child: Text(
                  textAlign: TextAlign.left,
                  textDirection: TextDirection.rtl,
                  widget.amPm!,
                  style: SystemFont.mainFont12W400,
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  SizedBox(
                    height: h * 0.024508929,
                    width: w * 0.562801932,
                    child: Text(
                      textAlign: TextAlign.right,
                      textDirection: TextDirection.rtl,
                      widget.name!,
                      style: GoogleFonts.almarai(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: SystemColors.textColorBlack,
                          wordSpacing: 0),
                    ),
                  ),
                  SizedBox(
                    height: h * 0.020044643,
                    width: w * 0.241545894,
                    child: Text(
                      maxLines: 1,
                      textAlign: TextAlign.right,
                      textDirection: TextDirection.rtl,
                      widget.message!,
                      style: GoogleFonts.almarai(
                          fontSize: 9,
                          fontWeight: FontWeight.w400,
                          color: SystemColors.textColorBlack,
                          wordSpacing: 1),
                    ),
                  ),
                ],
              ),
              SizedBox(
                width: w * 0.013478261,
              ),
              SizedBox(
                  height: h * 0.044642857,
                  width: w * 0.096618357,
                  child: const CircleAvatar(
                    backgroundColor: SystemColors.greyColor,
                  )),
            ],
          ),
          SizedBox(
            height: h * 0.009,
          ),
          SizedBox(
            height: h * 0.01,
            width: w * 0.734589372,
            child: const Divider(
              thickness: 1,
            ),
          )
        ],
      ),
    );
  }
}
