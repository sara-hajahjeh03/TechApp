import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class Button_widget extends StatefulWidget {
  final double? buttonHeight;
  final double buttonWidth;
  final double? borderRadius;
  final double? textSize;
  final double? iconSizedBox;
  final double? facebookSizedbox;
  final Color? buttonColor;
  final String buttonText;
  final FontWeight? textFontWeight;
  final Color? borderColor;
  final Color? textColor;
  final Color? activeButtonColor;
  final Color? inactiveButtonColor;
  final Color? activeTextColor;
  final Color? inactiveTextColor;
  late bool? activeButton1;
  late bool? activeButton2;
  final bool? isImageGoogle;
  final bool? isImageFacebook;
  final dynamic Function;

  Button_widget({
    Key? key,
    this.buttonHeight = SystemSize.textField_Height,
    required this.buttonWidth,
    this.buttonColor,
    this.borderRadius = 10,
    required this.buttonText,
    this.borderColor = Colors.transparent,
    this.textColor = Colors.white,
    this.activeButton1 = false,
    this.activeButton2 = false,
    this.activeButtonColor = Colors.white,
    this.inactiveButtonColor = Colors.white,
    this.activeTextColor,
    this.inactiveTextColor,
    this.textSize = SystemSize.textSize14,
    this.textFontWeight = FontWeight.w400,
    this.isImageGoogle = false,
    this.iconSizedBox = 3.864,
    this.isImageFacebook = false,
    this.facebookSizedbox = 0,
    this.Function,
  }) : super(key: key);

  @override
  State<Button_widget> createState() => _Button_widgetState();
}

class _Button_widgetState extends State<Button_widget> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return InkWell(
      onTap: widget.Function,
      child: Container(
        height: h * widget.buttonHeight!,
        width: widget.buttonWidth,
        decoration: BoxDecoration(
            border: Border.all(color: widget.borderColor!),
            color: widget.activeButton1! || widget.activeButton2!
                ? widget.activeButtonColor
                : widget.inactiveButtonColor,
            borderRadius:
                BorderRadius.all(Radius.circular(widget.borderRadius!))),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.isImageGoogle == true) ...[
                Image.asset('assets/googleIcon.png.png'),
                SizedBox(
                  width: widget.iconSizedBox,
                )
              ],
              if (widget.isImageFacebook == true) ...[
                SizedBox(
                  width: widget.facebookSizedbox,
                ),
                Image.asset('assets/facebookIcon.png.png'),
                SizedBox(
                  width: widget.iconSizedBox,
                )
              ],
              Text(
                widget.buttonText,
                style: GoogleFonts.almarai(
                    fontSize: widget.textSize,
                    fontWeight: widget.textFontWeight,
                    color: widget.activeButton1! || widget.activeButton2!
                        ? widget.activeTextColor
                        : widget.inactiveTextColor,
                    wordSpacing: 1),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
