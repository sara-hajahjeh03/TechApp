// ignore_for_file: camel_case_types

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class Dropdown_Widget extends StatefulWidget {
  final List dropDownItems;
  final String hintText;
  final double? fieldHeight;
  final double fieldWidth;
  final double textSize;
  final Color? textColor;
  static double minHeight = 0;
  static double maxHeight = 100;
  final String? prefixIcon;
  final double SizedboxWidth;

  final String? labelText;
  String? controller;

  Dropdown_Widget({
    Key? key,
    required this.dropDownItems,
    required this.hintText,
    this.labelText,
    this.controller,
    this.fieldHeight,
    required this.fieldWidth,
    required this.textSize,
    this.textColor,
    this.prefixIcon = "assets/Property 1=Arrow_1.png",
    required this.SizedboxWidth,
  }) : super(key: key);

  @override
  State<Dropdown_Widget> createState() => _Dropdown_WidgetState();
}

class _Dropdown_WidgetState extends State<Dropdown_Widget> {
  late String itemEditingController;
  late List<String> list = <String>[widget.dropDownItems as String];
  var selectedItem;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Container(
      height: widget.fieldHeight,
      width: widget.fieldWidth,
      constraints: BoxConstraints(
          maxHeight: Dropdown_Widget.maxHeight,
          minHeight: Dropdown_Widget.minHeight),
      child: DropdownButtonFormField<dynamic>(
        icon:
            const Visibility(visible: false, child: Icon(Icons.arrow_downward)),
        decoration: InputDecoration(
            filled: true,
            fillColor: SystemColors.lightGrey,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none),
            errorBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(10)),
              borderSide: BorderSide(width: 1, color: Colors.grey),
            ),
            hintTextDirection: TextDirection.rtl,
            alignLabelWithHint: true,
            prefixIcon: Image.asset(widget.prefixIcon!),
            contentPadding:
                EdgeInsets.symmetric(vertical: h / 60, horizontal: w / 40),
            hintText: widget.hintText,
            hintStyle: GoogleFonts.almarai(
              fontSize: widget.textSize,
              fontWeight: FontWeight.w400,
              color: widget.textColor,
            ),
            labelText: widget.labelText,
            floatingLabelBehavior: FloatingLabelBehavior.always),
        items: widget.dropDownItems
            .map((value) => DropdownMenuItem(
                  alignment: Alignment.centerRight,
                  value: value,
                  child: SizedBox(
                    width: widget.SizedboxWidth,
                    child: Text(
                      value,
                      textAlign: TextAlign.right,
                      style: GoogleFonts.almarai(
                        fontSize: widget.textSize,
                        fontWeight: FontWeight.w400,
                        color: widget.textColor,
                      ),
                    ),
                  ),
                ))
            .toList(),
        onSaved: (selectedItemType) {
          setState(() {
            widget.controller = selectedItemType.toString();
          });
        },
        validator: (value) {
          if (value == null) {
            setState(() {
              Dropdown_Widget.minHeight = 80;
            });
            return ("Please enter some text");
          }
          return null;
        },
        value: selectedItem,
        isExpanded: false,
        onChanged: (Object? value) {
          value = selectedItem.toString();
        },
      ),
    );
  }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///

class DropDown_Widget_FromFireBase extends StatefulWidget {
  String? editingController;
  late var selectedItem;
  final String hintText;
  final double? fieldHeight;
  final double fieldWidth;
  final double textSize;
  final Color? textColor;
  static double minHeight = 0;
  static double maxHeight = 100;
  final String? prefixIcon;
  final double SizedboxWidth;
  final String? labelText;
  final String itemsCollection;
  final ValueChanged<dynamic> valueChanged;

  DropDown_Widget_FromFireBase(
      {Key? key,
      required this.editingController,
      required this.selectedItem,
      required this.hintText,
      this.fieldHeight,
      required this.fieldWidth,
      required this.textSize,
      this.textColor = SystemColors.textColorBlack,
      this.prefixIcon = "assets/Property 1=Arrow_1.png",
      required this.SizedboxWidth,
      this.labelText,
      required this.itemsCollection,
      required this.valueChanged})
      : super(key: key);

  @override
  State<DropDown_Widget_FromFireBase> createState() =>
      _DropDown_Widget_FromFireBaseState();
}

class _DropDown_Widget_FromFireBaseState
    extends State<DropDown_Widget_FromFireBase> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection(widget.itemsCollection)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            const Text("Loading.....");
          } else {
            List<DropdownMenuItem> items = [];
            for (int i = 0; i < snapshot.data!.docs.length; i++) {
              DocumentSnapshot snap = snapshot.data!.docs[i];
              items.add(
                DropdownMenuItem(
                  value: snap.id,
                  alignment: Alignment.centerRight,
                  child: SizedBox(
                    width: widget.SizedboxWidth,
                    child: Text(
                      snap.id,
                      textAlign: TextAlign.right,
                      style: GoogleFonts.almarai(
                        fontSize: widget.textSize,
                        fontWeight: FontWeight.w400,
                        color: widget.textColor,
                      ),
                    ),
                  ),
                ),
              );
            }
            return Container(
              height: widget.fieldHeight,
              width: widget.fieldWidth,
              constraints: BoxConstraints(
                  maxHeight: Dropdown_Widget.maxHeight,
                  minHeight: Dropdown_Widget.minHeight),
              child: DropdownButtonFormField<dynamic>(
                icon: const Visibility(
                    visible: false, child: Icon(Icons.arrow_downward)),
                decoration: InputDecoration(
                    filled: true,
                    fillColor: SystemColors.lightGrey,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none),
                    errorBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      borderSide: BorderSide(width: 1, color: Colors.grey),
                    ),
                    hintTextDirection: TextDirection.rtl,
                    alignLabelWithHint: true,
                    prefixIcon: Image.asset(widget.prefixIcon!),
                    contentPadding: EdgeInsets.symmetric(
                        vertical: h / 60, horizontal: w / 40),
                    hintText: widget.hintText,
                    hintStyle: GoogleFonts.almarai(
                      fontSize: widget.textSize,
                      fontWeight: FontWeight.w400,
                      color: widget.textColor,
                    ),
                    labelText: widget.labelText,
                    floatingLabelBehavior: FloatingLabelBehavior.always),
                items: items,
                alignment: Alignment.centerRight,
                onChanged: widget.valueChanged,
                validator: (value) =>
                    value == null ? 'This field is required' : null,
                value: widget.selectedItem,
                isExpanded: false,
                hint: Text(
                  widget.hintText,
                  style: GoogleFonts.almarai(
                    fontSize: widget.textSize,
                    fontWeight: FontWeight.w400,
                    color: widget.textColor,
                  ),
                ),
              ),
            );
          }
          return const SizedBox
              .shrink(); //If it doesn't meet any condition then a sized box with no size is returned
        });
  }
}
