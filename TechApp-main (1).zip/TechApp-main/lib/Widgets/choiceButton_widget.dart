// ignore_for_file: prefer_const_declarations

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class ChoiceButton extends StatefulWidget {
  final double boxHeight;
  final double boxWidth;
  final double? paddingOnPressed;
  final double iconPadding;
  final double? textSize;
  final double? iconSize;
  final String icon;
  late bool? userCheck;
  late bool? providerCheck;
  final Function? iconOnPressed;
  late bool? User;
  final String text;
  final Color? boxColor;
  final dynamic onTap;

  ChoiceButton(
      {Key? key,
      required this.boxHeight,
      required this.boxWidth,
      required this.icon,
      required this.text,
      required this.iconPadding,
      this.paddingOnPressed = 0,
      this.userCheck = false,
      this.providerCheck = false,
      this.iconOnPressed,
      this.User,
      this.textSize,
      this.boxColor = SystemColors.greyLoginBoxColor,
      this.onTap,
      this.iconSize = 50})
      : super(key: key);

  @override
  State<ChoiceButton> createState() => _ChoiceButtonState();
}

class _ChoiceButtonState extends State<ChoiceButton> {
  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return InkWell(
        onTap: widget.onTap,
        child: PhysicalModel(
          color: SystemColors.greyColor,
          elevation: 2,
          borderRadius: const BorderRadius.all(Radius.circular(16)),
          child: Container(
            height: widget.boxHeight,
            width: widget.boxWidth,
            decoration: BoxDecoration(
                color: widget.boxColor,
                borderRadius: const BorderRadius.all(Radius.circular(16))),
            child: Column(children: [
              if (widget.userCheck == true) ...[
                SizedBox(
                  height:
                      MediaQuery.of(context).size.height * SystemSize.space16,
                ),
                Padding(
                  padding: EdgeInsets.only(
                    right:
                        MediaQuery.of(context).size.height * SystemSize.space16,
                  ),
                  child: Align(
                      alignment: Alignment.centerRight,
                      child: Image.asset("assets/Check.png")),
                ),
              ],
              if (widget.providerCheck == true) ...[
                SizedBox(
                  height:
                      MediaQuery.of(context).size.height * SystemSize.space16,
                ),
                Padding(
                  padding: EdgeInsets.only(
                    right:
                        MediaQuery.of(context).size.height * SystemSize.space16,
                  ),
                  child: Align(
                      alignment: Alignment.centerRight,
                      child: Image.asset("assets/Check.png")),
                ),
              ],
              Padding(
                padding: EdgeInsets.only(
                    top: widget.userCheck! || widget.providerCheck!
                        ? widget.paddingOnPressed!
                        : widget.iconPadding),
                child: Column(
                  children: [
                    IconButton(
                      icon: Image.asset(
                        widget.icon,
                      ),
                      iconSize: widget.iconSize,
                      onPressed: widget.iconOnPressed!(),
                    ),
                    Text(widget.text,
                        style: GoogleFonts.almarai(
                            fontSize: widget.textSize,
                            fontWeight: FontWeight.w400,
                            color: SystemColors.textColorBlack,
                            wordSpacing: 1))
                  ],
                ),
              ),
            ]),
          ),
        ),
      );
    });
  }
}
