import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:readmore/readmore.dart';
import 'package:tech_app_v1/UserScreens/viewProviderProfile.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';

class providerOffer_widget extends StatelessWidget {
  const providerOffer_widget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return PhysicalModel(
      color: SystemColors.whiteBackgroundColor,
      elevation: 2,
      borderRadius: const BorderRadius.all(Radius.circular(16)),
      child: Container(
        height: h * 0.31,
        width: w * 0.92,
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(16)),
        ),
        child: Stack(
          children: [
            Padding(
              padding: EdgeInsets.only(right: w * 0.039, top: h * 0.018),
              child: const Align(
                alignment: Alignment.topRight,
                child: CircleAvatar(
                  radius: 40,
                  backgroundColor: SystemColors.greyColor,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: h * 0.03, right: w * 0.25),
              child: Align(
                alignment: Alignment.topRight,
                child: Text(
                  'محمد العطار',
                  style: GoogleFonts.almarai(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: SystemColors.textColorBlack,
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: h * 0.060, right: w * 0.25),
              child: Align(
                alignment: Alignment.topRight,
                child: Text(
                  'ميكانيكى سيارات',
                  style: GoogleFonts.almarai(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: SystemColors.greyColor),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: h * 0.13, right: w * 0.05),
              child: Align(
                alignment: Alignment.topRight,
                child: Text(
                  ':العرض المقدم',
                  style: GoogleFonts.almarai(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: SystemColors.textColorBlack,
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: h * 0.07, right: w * 0.01),
              child: Align(
                child: SizedBox(
                  width: 0.84 * w,
                  height: h * 0.058,
                  child: SingleChildScrollView(
                    child: ReadMoreText(
                      'يمكننى ان اقوم بكل اعمالك الكهربائيه فى منزلك باسرع وقت واسهل وائمن طريقه وبافضل سعر ممكن يمكننى ان اقوم بكل اعمالك الكهربائيه فى منزلك باسرع وقت واسهل وائمن طريقه وبافضل سعر ممكن',
                      style: GoogleFonts.almarai(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: SystemColors.textColorBlack,
                        wordSpacing: 2,
                      ),
                      trimLines: 3,
                      colorClickableText: SystemColors.mainColor,
                      trimMode: TrimMode.Line,
                      trimCollapsedText: 'المزيد',
                      trimExpandedText: 'اخفاء',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right,
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: h * 0.23),
              child: Align(
                alignment: Alignment.topCenter,
                child: Button_widget(
                  buttonWidth: w * 0.85,
                  buttonText: 'تواصل',
                  activeButton1: true,
                  activeButtonColor: SystemColors.mainColor,
                  activeTextColor: SystemColors.whiteBackgroundColor,
                  Function: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation1, animation2) =>
                             ViewProviderProfile(),
                        transitionDuration: Duration.zero,
                        reverseTransitionDuration: Duration.zero,
                      ),
                      (route) =>
                          true, //if you want to disable back feature set to false
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
