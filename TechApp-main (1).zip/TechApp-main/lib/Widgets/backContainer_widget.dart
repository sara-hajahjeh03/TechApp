import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class backContainer_widget extends StatelessWidget {
  final double height;
  final double width;
  final Color color;
  final Color? ShadowColor;
  final double? elevation;
  final Widget? child;
  final double? radius;
  final Color? DottedBorderColor;
  final double? DottedBorderStrokeWidth;
  final double? DottedBorderStrokePattern;
  final bool withIcon;
  final String? rowText;
  final String? rowIcon;
  final dynamic function;

  const backContainer_widget(
      {Key? key,
      required this.height,
      required this.width,
      required this.color,
      this.ShadowColor = Colors.white,
      this.elevation = 0,
      this.child,
      this.radius = 0,
      this.DottedBorderColor = Colors.transparent,
      this.DottedBorderStrokeWidth = 0,
      this.DottedBorderStrokePattern = 1,
      this.withIcon = false,
      this.rowText,
      this.rowIcon,
      this.function})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return InkWell(
      onTap: function,
      child: PhysicalModel(
        color: ShadowColor!,
        elevation: elevation!,
        borderRadius: BorderRadius.all(Radius.circular(radius!)),
        child: DottedBorder(
          strokeWidth: DottedBorderStrokeWidth!,
          color: DottedBorderColor!,
          dashPattern: [DottedBorderStrokePattern!, DottedBorderStrokePattern!],
          borderType: BorderType.RRect,
          radius: Radius.circular(radius!),
          child: Container(
            height: height,
            width: width,
            decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.all(Radius.circular(radius!))),
            child: withIcon
                ? Padding(
                    padding: EdgeInsets.only(right: 0.039 * w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          rowText!,
                          style: GoogleFonts.almarai(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              color: SystemColors.textColorBlack,
                              wordSpacing: 1),
                        ),
                        SizedBox(
                          width: 0.039 * w,
                        ),
                        Image.asset(rowIcon!),
                      ],
                    ),
                  )
                : child,
          ),
        ),
      ),
    );
  }
}
