import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class OffersScroll_widget extends StatefulWidget {
  final double height;
  final double width;
  final double spacing;
  final double? spaceUnderImage;
  final double dotHeight;
  final double dotWidth;

  const OffersScroll_widget(
      {Key? key,
      required this.height,
      required this.width,
      required this.spacing,
      this.spaceUnderImage = 10,
      required this.dotHeight,
      required this.dotWidth})
      : super(key: key);

  @override
  State<OffersScroll_widget> createState() => _OffersScroll_widgetState();
}

class _OffersScroll_widgetState extends State<OffersScroll_widget> {
  final urlImages = [];
  int activeIndex = 0;
  Future getDocId() async {
    await FirebaseFirestore.instance.collection('HomePageOfferPics').get().then(
          (snapshot) => snapshot.docs.forEach((document) {
            final url = document.data().values.first;
            urlImages.add(url);
          }),
        );
  }

  late Future<dynamic> dataFuture;

  @override
  void initState() {
    super.initState();
    dataFuture = getDocId();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder(
        future: dataFuture,
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              return Column(
                children: [
                  CarouselSlider.builder(
                      itemCount: urlImages.length,
                      options: CarouselOptions(
                          height: widget.height,
                          onPageChanged: (index, reason) {
                            setState(() {
                              activeIndex = index;
                            });
                          }),
                      itemBuilder: (context, index, realIndex) {
                        final urlImage = urlImages[index];

                        return buildImage(urlImage, index);
                      }),
                  SizedBox(
                    height: widget.spaceUnderImage,
                  ),
                  buildIndecator()
                ],
              );
            }
          } else {
            return Column(
              children: [
                Container(
                  height: widget.height,
                  width: widget.width,
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(16))),
                  child: const Center(
                    child: CircularProgressIndicator(),
                  ),
                ),
                SizedBox(
                  height: widget.spaceUnderImage,
                ),
              ],
            );
          }
        },
      );

  Widget buildImage(String urlImage, int index) => Container(
        width: widget.width,
        decoration: const BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.all(Radius.circular(16))),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: CachedNetworkImage(
              fadeInDuration: const Duration(microseconds: 0),
              fadeOutDuration: const Duration(microseconds: 0),
              key: UniqueKey(),
              imageUrl: urlImage,
              fit: BoxFit.fill,
              placeholder: (context, url) => Container()
              // errorWidget: ,
              ),
        ),
      );

  Widget buildIndecator() => AnimatedSmoothIndicator(
        activeIndex: activeIndex,
        count: urlImages.length,
        effect: SlideEffect(
            dotHeight: widget.dotHeight,
            dotWidth: widget.dotWidth,
            dotColor: SystemColors.greyColor,
            activeDotColor: SystemColors.mainColor),
      );
}
