import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/SharedScreens/chatRoom_Screen.dart';
import 'package:tech_app_v1/UserScreens/viewProviderProfile.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/services/userServices.dart';

class ProviderInfoBox_Widget extends StatefulWidget {
  final bool profile;
  final double elevation;
  final String? name;
  final String? occupation;
  final String? city;
  final String? documentId;
  final String? userUID;

  const ProviderInfoBox_Widget({
    Key? key,
    this.profile = true,
    this.elevation = 2,
    this.name = 'محمد العطار',
    this.occupation = 'حداد',
    this.city = 'عمان',
    this.documentId,
    this.userUID,
  }) : super(key: key);

  @override
  State<ProviderInfoBox_Widget> createState() => _ProviderInfoBox_WidgetState();
}

class _ProviderInfoBox_WidgetState extends State<ProviderInfoBox_Widget> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return PhysicalModel(
      color: Colors.white,
      elevation: widget.elevation,
      borderRadius: const BorderRadius.all(Radius.circular(16)),
      child: Container(
          height: 0.173 * h,
          width: 0.9227 * w,
          decoration: const BoxDecoration(
              color: SystemColors.whiteBackgroundColor,
              borderRadius: BorderRadius.all(Radius.circular(16))),
          child: Stack(
            children: [
              Padding(
                padding: EdgeInsets.only(right: 0.0386 * w),
                child: const Align(
                  alignment: Alignment.centerRight,
                  child: CircleAvatar(
                    radius: 43,
                    backgroundColor: Colors.grey,
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 0.0324 * h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      widget.name!,
                      style: GoogleFonts.almarai(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: SystemColors.textColorBlack),
                    ),
                    SizedBox(width: 0.019 * w),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '4.5',
                          style: SystemFont.mainFont14W400,
                        ),
                        const Icon(
                          Icons.star,
                          size: 20,
                          color: Color(0xFFE0B315),
                        ),
                        SizedBox(width: 0.256 * w),
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 0.0598 * h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      widget.occupation!,
                      style: GoogleFonts.almarai(
                          fontSize: SystemSize.textSize14,
                          fontWeight: FontWeight.w400,
                          color: const Color(0xFF7D7D7D),
                          wordSpacing: 1),
                    ),
                    SizedBox(
                      width: 0.273 * w,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 0.0931 * h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'المحافظة: ${widget.city}',
                      style: GoogleFonts.almarai(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: SystemColors.textColorBlack),
                    ),
                    SizedBox(
                      width: 0.019 * w,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image.asset('assets/locationIcon.png'),
                        SizedBox(
                          width: 0.256 * w,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 0.1328 * h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          PageRouteBuilder(
                            pageBuilder: (context, animation1, animation2) =>
                                ViewProviderProfile(
                                    documentId: widget.documentId),
                            transitionDuration: Duration.zero,
                            reverseTransitionDuration: Duration.zero,
                          ),
                          (route) =>
                              true, //if you want to disable back feature set to false
                        );
                      },
                      child: widget.profile
                          ? Text(
                              'مشاهدة الملف الشخصي',
                              style: GoogleFonts.almarai(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: SystemColors.mainColor),
                            )
                          : RichText(
                              text: TextSpan(
                                style: GoogleFonts.almarai(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: SystemColors.mainColor),
                                children: const <TextSpan>[
                                  TextSpan(
                                      text: 'الخبرة: ',
                                      style: TextStyle(
                                          color: SystemColors.textColorBlack)),
                                  TextSpan(
                                      text: '7 سنوات',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      )),
                                ],
                              ),
                            ),
                    ),
                    SizedBox(
                      width: 0.256 * w,
                      height: 1,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 0.1071 * h, left: 0.0386 * w),
                child: InkWell(
                    onTap: () {
                      navigate(
                          context,
                          ChatRoom(
                            username: widget.name,
                            userUID: widget.userUID,
                          ),
                          true);
                    },
                    child: Image.asset('assets/chatIcon.png')),
              ),
              Padding(
                padding: EdgeInsets.only(top: 0.0391 * h, left: 0.0386 * w),
                child: Image.asset('assets/phoneIcon.png'),
              )
            ],
          )),
    );
  }
}
