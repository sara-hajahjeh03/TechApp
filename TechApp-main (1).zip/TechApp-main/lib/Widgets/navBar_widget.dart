import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tech_app_v1/SharedScreens/chat_screen.dart';
import 'package:tech_app_v1/UserScreens/home_Screen.dart';
import 'package:tech_app_v1/UserScreens/more_Screen.dart';
import 'package:tech_app_v1/UserScreens/offers_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/services/userServices.dart';

class navBar_widget extends StatelessWidget {
  const navBar_widget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;

    return Container(
      height: h * 0.09,
      width: w,
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topRight: Radius.circular(16),
          topLeft: Radius.circular(16),
        ),
        child: BottomAppBar(
          elevation: 20,
          shape: const CircularNotchedRectangle(),
          notchMargin: 10,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: h * 0.07,
              width: w,
              decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              )),
              child: Stack(
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: w * 0.067),
                    child: InkWell(
                      borderRadius: const BorderRadius.all(Radius.circular(33)),
                      child: TextButton.icon(
                        icon: Column(
                          children: [
                            Image.asset('assets/moreNavIcon.png'),
                            SizedBox(
                              height: h * 0.003,
                            ),
                            Text(
                              'المزيد',
                              style: GoogleFonts.tajawal(
                                  fontSize: 10, color: const Color(0xFF3E3E46)),
                            ),
                          ],
                        ),
                        label: const Text(''),
                        onPressed: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const MoreScreen(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                false, //if you want to disable back feature set to false
                          );
                        },
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: w * 0.26),
                    child: TextButton.icon(
                      icon: Column(
                        children: [
                          Image.asset('assets/chatNavIcon.png'),
                          SizedBox(
                            height: h * 0.003,
                          ),
                          Text(
                            'الرسائل',
                            style: GoogleFonts.tajawal(
                                fontSize: 10, color: const Color(0xFF3E3E46)),
                          ),
                        ],
                      ),
                      label: const Text(''),
                      onPressed: () {
                        navigate(context, ChatScreen(), false);
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: w * 0.642),
                    child: TextButton.icon(
                      icon: Column(children: [
                        Image.asset('assets/offersNavIcon.png'),
                        SizedBox(
                          height: h * 0.003,
                        ),
                        Text(
                          'العروض',
                          style: GoogleFonts.tajawal(
                              fontSize: 10, color: const Color(0xFF3E3E46)),
                        ),
                      ]),
                      label: const Text(''),
                      onPressed: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          PageRouteBuilder(
                            pageBuilder: (context, animation1, animation2) =>
                                const offers_Screen(),
                            transitionDuration: Duration.zero,
                            reverseTransitionDuration: Duration.zero,
                          ),
                          (route) =>
                              false, //if you want to disable back feature set to false
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: w * 0.84),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextButton.icon(
                          icon: Column(children: [
                            Image.asset('assets/homeNavIcon.png'),
                            SizedBox(
                              height: h * 0.003,
                            ),
                            Text(
                              'الرئيسية',
                              style: GoogleFonts.tajawal(
                                  fontSize: 10, color: const Color(0xFF3E3E46)),
                            ),
                          ]),
                          label: const Text(''),
                          onPressed: () {
                            Navigator.pushAndRemoveUntil(
                              context,
                              PageRouteBuilder(
                                pageBuilder:
                                    (context, animation1, animation2) =>
                                        home_Screen(),
                                transitionDuration: Duration.zero,
                                reverseTransitionDuration: Duration.zero,
                              ),
                              (route) =>
                                  false, //if you want to disable back feature set to false
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget floatingActionButton(final dynamic navigateTo, context) {
    return FloatingActionButton(
      onPressed: () {
        Navigator.pushAndRemoveUntil(
          context,
          PageRouteBuilder(
            pageBuilder: (context, animation1, animation2) => navigateTo,
            transitionDuration: Duration.zero,
            reverseTransitionDuration: Duration.zero,
          ),
          (route) => true, //if you want to disable back feature set to false
        );
      },
      backgroundColor: SystemColors.mainColor,
      child: const Icon(
        Icons.add,
        size: 40,
      ),
    );
  }
}
