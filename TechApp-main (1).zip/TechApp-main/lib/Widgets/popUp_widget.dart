import 'package:flutter/material.dart';
import 'package:tech_app_v1/UserScreens/home_Screen.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';

class popUp_Widget extends StatefulWidget {
  const popUp_Widget(BuildContext context, {Key? key}) : super(key: key);

  @override
  State<popUp_Widget> createState() => _popUp_WidgetState();
}

class _popUp_WidgetState extends State<popUp_Widget> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Dialog(
      
      insetPadding: const EdgeInsets.all(0),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(16))),
      child: SizedBox(
        height: h * 0.35,
        width: w * 0.923,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            SizedBox(
              height: h * 0.027,
            ),
            SizedBox(
                width: w * 0.242,
                height: h * 0.11,
                child: Image.asset('assets/doneImage.png')),
            SizedBox(
              height: h * 0.019,
            ),
            SizedBox(
              height: h * 0.048,
              width: w * 0.519,
              child: Text(
                "تمت اضافة طلبك بنجاح سوف يتم مراجعه الطلب في اسرع وقت",
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: SystemFont.mainFont14W400,
              ),
            ),
            SizedBox(
              height: h * 0.019,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Button_widget(
                  buttonWidth: w * 0.386,
                  buttonText: 'الرئيسيه',
                  activeButton1: true,
                  activeButtonColor: SystemColors.whiteBackgroundColor,
                  activeTextColor: SystemColors.mainColor,
                  borderColor: SystemColors.mainColor,
                  Function: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation1, animation2) =>
                            home_Screen(),
                        transitionDuration: Duration.zero,
                        reverseTransitionDuration: Duration.zero,
                      ),
                      (route) =>
                          false, //if you want to disable back feature set to false
                    );
                  },
                ),
                Button_widget(
                  buttonWidth: w * 0.386,
                  buttonText: 'اضافة طلب اخر',
                  activeButton1: true,
                  activeButtonColor: SystemColors.mainColor,
                  activeTextColor: SystemColors.whiteBackgroundColor,
                  Function: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation1, animation2) =>
                            const UserOrderScreen(),
                        transitionDuration: Duration.zero,
                        reverseTransitionDuration: Duration.zero,
                      ),
                      (route) =>
                          false, //if you want to disable back feature set to false
                    );
                  },
                ),
              ],
            ),
            SizedBox(
              height: h * 0.028,
            ),
          ],
        ),
      ),
    );
  }
}
