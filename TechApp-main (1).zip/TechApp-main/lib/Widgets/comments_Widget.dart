import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:readmore/readmore.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class CommentsWidget extends StatefulWidget {
  final double height;
  final double width;
  final Color? color;

  CommentsWidget(
      {Key? key,
      required this.height,
      required this.width,
      this.color = SystemColors.whiteBackgroundColor})
      : super(key: key);

  @override
  State<CommentsWidget> createState() => _CommentsWidgetState();
}

class _CommentsWidgetState extends State<CommentsWidget> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return PhysicalModel(
      color: SystemColors.whiteBackgroundColor,
      elevation: 3,
      borderRadius: BorderRadius.all(Radius.circular(16)),
      child: Container(
        height: widget.height,
        width: widget.width,
        decoration: BoxDecoration(
          color: widget.color,
          borderRadius: const BorderRadius.all(Radius.circular(16)),
        ),
        child: Stack(
          children: [
            Padding(
              padding: EdgeInsets.only(top: h * 0.0179, right: 0.039 * w),
              child: const Align(
                alignment: Alignment.topRight,
                child: CircleAvatar(
                  backgroundColor: SystemColors.textColorBlack,
                  radius: 25,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(right: 0.19 * w, top: h * 0.025),
              child: Align(
                alignment: Alignment.topRight,
                child: Text(
                  'محمد العطار',
                  style: SystemFont.mainFont14W400,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 0.033 * h, left: 0.039 * w),
              child: Text(
                'منذ يوم واحد',
                style: SystemFont.mainFont14W400,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 0.091 * h, right: 0.039 * w),
              child: Align(
                alignment: Alignment.topRight,
                child: SizedBox(
                  width: 0.60 * w,
                  child: SingleChildScrollView(
                    child: ReadMoreText(
                      'انى ارشح وبقوه العمل مع المهندس محمد لانه يملك من الخبره الكافيه والكثيره مما ساعدني في حل مشكلاتى والتعامل معها بالشكل المهنى الصحيح ومواكبه العصر بافضل الحلول الممكنه مما يؤدى الي اتمام العمل',
                      style: GoogleFonts.almarai(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: SystemColors.textColorBlack,
                        wordSpacing: 2,
                      ),
                      trimLines: 3,
                      colorClickableText: SystemColors.mainColor,
                      trimMode: TrimMode.Line,
                      trimCollapsedText: 'المزيد',
                      trimExpandedText: 'اخفاء',
                      textDirection: TextDirection.rtl,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
