import 'package:flutter/material.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class PleaseWaitWidget extends StatelessWidget {
  const PleaseWaitWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Dialog(
      insetPadding: const EdgeInsets.all(0),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(16))),
      child: SizedBox(
        height: 0.25 * h,
        width: 0.923 * w,
        child: Column(
          children: [
            SizedBox(
              height: 0.027 * h,
            ),
            Text(
              'Please wait...',
              textDirection: TextDirection.ltr,
              textAlign: TextAlign.center,
              style: SystemFont.mainFont20W700,
            ),
            SizedBox(height: 0.06 * h),
            CircularProgressIndicator()
          ],
        ),
      ),
    );
  }
}
