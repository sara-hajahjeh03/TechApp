import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class AppBar_Widget extends StatefulWidget {
  final String? rightIcon;
  final String titleText;
  final double? appBarheight;
  final Color? titleColor;
  final dynamic navigateTo;
  final bool icon;
  final bool? leftIcon;
  final dynamic leadingTextFunction;

  AppBar_Widget({
    Key? key,
    this.rightIcon = 'assets/backArrow.png',
    required this.titleText,
    this.titleColor = SystemColors.textColorBlack,
    this.appBarheight = SystemSize.appBarheight,
    this.navigateTo,
    this.icon = true,
    this.leftIcon = false,
    this.leadingTextFunction,
  }) : super(key: key);

  @override
  State<AppBar_Widget> createState() => _AppBar_WidgetState();
}

class _AppBar_WidgetState extends State<AppBar_Widget> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return AppBar(
      leading: widget.leftIcon!
          ? Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 0.03 * w),
                child: InkWell(
                  onTap: widget.leadingTextFunction,
                  child: Text("تعديل",
                      style: GoogleFonts.almarai(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: SystemColors.textColorBlack,
                          wordSpacing: 1)),
                ),
              ))
          : Container(),
      toolbarHeight: widget.appBarheight,
      title: Text(
        widget.titleText,
        style: SystemFont.tajawalS16W500,
      ),
      centerTitle: true,
      backgroundColor: Colors.transparent,
      elevation: 0,
      actions: [
        IconButton(
          onPressed: () {
            if (widget.navigateTo != null) {
              FocusManager.instance.primaryFocus?.unfocus();
              Navigator.pushReplacement(
                context,
                PageRouteBuilder(
                  pageBuilder: (context, animation1, animation2) =>
                      widget.navigateTo,
                  transitionDuration: Duration.zero,
                  reverseTransitionDuration: Duration.zero,
                ),
              );
            } else {
              Navigator.of(context).pop();
            }
          },
          icon: widget.icon ? Image.asset(widget.rightIcon!) : Container(),
        ),
      ],
    );
  }
}
