// ignore_for_file: non_constant_identifier_names

class UserModel {
  String? uid;
  String? email;
  String? FullName;
  String? aboutJob;
  String? jobLocation;
  List<String>? orderPics;
  String? profilePic;

  UserModel({
    this.uid,
    this.email,
    this.FullName,
    this.aboutJob,
    this.jobLocation,
    this.orderPics,
    this.profilePic,
  });
//reciving data from server
  factory UserModel.fromMap(map) {
    return UserModel(
      uid: map['uid'],
      email: map['email'],
      FullName: map['FullName'],
      aboutJob: map['aboutJob'],
      jobLocation: map['jobLocation'],
      orderPics: map['orderPics'],
      profilePic: map['profilePic'],
    );
  }

// sending data to our server
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'FullName': FullName,
      'aboutJob': aboutJob,
      'jobLocation': jobLocation,
      'orderPics': orderPics,
      'profilePic': profilePic,
    };
  }
}
