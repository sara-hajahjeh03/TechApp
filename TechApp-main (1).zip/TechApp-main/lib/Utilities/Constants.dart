import 'dart:core';
import 'dart:ui';

import 'package:flutter/src/painting/text_style.dart';
import 'package:google_fonts/google_fonts.dart';

class SystemColors {
  static const mainColor = Color(0xFF23408E);
  static const textColorBlack = Color(0xFF000000);
  static const greyColor = Color(0xFF9E9E9E);
  static const messageIsNotMeColor = Color(0xFFE7E7E7);
  static const greyLoginBoxColor = Color(0xFFD9D9D9);
  static const whiteBackgroundColor = Color(0xFFFFFFFF);
  static const iconColor = Color(0xFF000000);
  static const lightGrey = Color(0xFFF1F1F1);
  static const inactiveTextColor = Color(0xFF6D6D6D);
  static const textFieldTextColor = Color(0xFF3E3E46);
}

class SystemSize {
  static double smallTextSize = 19;
  static double bigTextSize = 36;
  static double mediumTextSize = 20;
  static double sizedBoxImageHeight = 46.21;
  static double sizedBoxImageWidth = 100;
  static double textSize20 = 20;
  static const double textSize14 = 14;
  static double space16 = 0.01;
  static const double textField_Height = 0.0665;
  static double textField_width = 84.54;
  static double SizedboxWidth = 70;
  static const double appBarheight = 7.7;
}

class SystemFont {
  static TextStyle mainFontMedium = GoogleFonts.almarai(
      fontSize: SystemSize.mediumTextSize,
      fontWeight: FontWeight.w400,
      color: SystemColors.mainColor,
      wordSpacing: 1);

  static TextStyle tajawalS16W500 = GoogleFonts.tajawal(
      fontSize: SystemSize.smallTextSize,
      fontWeight: FontWeight.w500,
      color: SystemColors.textColorBlack);

  static TextStyle tajawalS16W700 = GoogleFonts.tajawal(
      fontSize: SystemSize.smallTextSize,
      fontWeight: FontWeight.w700,
      color: Color(0xFF23408E));

  static TextStyle mainFont14W400 = GoogleFonts.almarai(
      fontSize: SystemSize.textSize14,
      fontWeight: FontWeight.w400,
      color: SystemColors.textColorBlack,
      wordSpacing: 1);
      static TextStyle mainFont12W400 = GoogleFonts.almarai(
      fontSize: 12,
      fontWeight: FontWeight.w400,
      color: SystemColors.textColorBlack,
      wordSpacing: 1);
  static TextStyle mainFont14W400Blue = GoogleFonts.almarai(
      fontSize: SystemSize.textSize14,
      fontWeight: FontWeight.w400,
      color: SystemColors.mainColor,
      wordSpacing: 1);

  static TextStyle mainFont36 = GoogleFonts.almarai(
      fontSize: SystemSize.bigTextSize,
      fontWeight: FontWeight.w700,
      color: SystemColors.textColorBlack);

  static TextStyle mainFont20W700 = GoogleFonts.almarai(
      fontSize: SystemSize.textSize20,
      fontWeight: FontWeight.w700,
      color: SystemColors.textColorBlack);
  static TextStyle mainFont20W400 = GoogleFonts.almarai(
      fontSize: SystemSize.textSize20,
      fontWeight: FontWeight.w400,
      color: SystemColors.textColorBlack);
}
