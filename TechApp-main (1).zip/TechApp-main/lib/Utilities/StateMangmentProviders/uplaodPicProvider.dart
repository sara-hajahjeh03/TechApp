import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';

class UploadPicProvider with ChangeNotifier {
  bool _isPickUplaoded = false;
  late String _profilePicController = '';
  var _profilePicURL;
  bool _isProfilePicUpdated = false;
  User? user = FirebaseAuth.instance.currentUser;

  get profilePicURL => _profilePicURL;
  String get profilePicController => _profilePicController;
  bool get isPicUploaded => _isPickUplaoded;
  bool get isProfilePicUpdated => _isProfilePicUpdated;
  set changeProfilePicController(String change) {
    _profilePicController = change;
  }

  set changeIsProfilePicUpdated(bool updated) {
    _isProfilePicUpdated = updated;
  }

  set changeIsPickUploaded(bool uploaded) {
    _isPickUplaoded = uploaded;
  }

  void uploadPics() async {
    _profilePicController = '';

    final image = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (image != null) {
      _profilePicURL = image;
    }
    Reference ref = FirebaseStorage.instance
        .ref()
        .child('User_ProfilePics/${DateTime.now()}.png');

    await ref.putFile(File(profilePicURL.path));

    ref.getDownloadURL().then((value) {
      _profilePicController = value;
      _isPickUplaoded = true;
      _isProfilePicUpdated = true;
      user?.updatePhotoURL(value);

      notifyListeners();
    });

    notifyListeners();
  }
}
