// ignore_for_file: file_names, use_build_context_synchronously
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/userAccount.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/Widgets/text_field_widget.dart';
import 'package:tech_app_v1/userModel/user_models.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Utilities/StateMangmentProviders/uplaodPicProvider.dart';
import 'package:user_profile_avatar/user_profile_avatar.dart';
import 'package:tech_app_v1/services/userServices.dart';

class userEditAccount extends StatefulWidget {
  const userEditAccount({Key? key}) : super(key: key);

  @override
  State<userEditAccount> createState() => _userEditAccountState();
}

class _userEditAccountState extends State<userEditAccount> {
  User? user = FirebaseAuth.instance.currentUser;
  UserModel loggedInUser = UserModel();
  final _auth = FirebaseAuth.instance;

  var _formKey = GlobalKey<FormState>();
  var _passwordformKey = GlobalKey<FormState>();
  bool checkCurrentPasswordValid = true;

  String? profilePicUpdate;

  @override
  void dispose() {
    fullNameEditingController.dispose();

    super.dispose();
  }

  //Editing Controllers
  final TextEditingController fullNameEditingController =
      TextEditingController();
  final TextEditingController emailEditingController = TextEditingController();

  late String? name = user?.displayName;
  late String? email = user!.email;

  @override
  void initState() {
    super.initState();

    // Get the photo URL from Firebase
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Sizer(builder: (context, orientation, deviceType) {
        return GestureDetector(
          onTap: () {
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            backgroundColor: SystemColors.whiteBackgroundColor,
            body: SingleChildScrollView(
              child: Column(
                children: [
                  AppBar_Widget(
                    navigateTo: UserAccount(),
                    titleText: 'تعديل المعلوات',
                    rightIcon: 'assets/backArrow.png',
                    appBarheight: SystemSize.appBarheight.h,
                  ),
                  SizedBox(
                    height: 3.46.h,
                  ),
                  Padding(
                    padding: EdgeInsets.only(right: 3.86.w),
                    child: Align(
                      alignment: Alignment.topRight,
                      child: Stack(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${UserSharedPref.getUsername()}',
                                    style: SystemFont.mainFont20W700,
                                  ),
                                  SizedBox(
                                    height: 0.7.h,
                                  ),
                                  Text(
                                  user!.uid.substring(0, 10),
                                    style: GoogleFonts.almarai(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w400,
                                        color: const Color(0xFF494949)),
                                  )
                                ],
                              ),
                              SizedBox(
                                width: 2.5.w,
                              ),
                              UserProfileAvatar(
                                avatarUrl: '${UserSharedPref.getProfilePic()}',
                                avatarSplashColor: SystemColors.greyColor,
                                onAvatarTap: () {
                                  context
                                      .read<UploadPicProvider>()
                                      .uploadPics();
                                },
                                radius: 55,
                                isActivityIndicatorSmall: false,
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 2.68.h,
                  ),
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        TextField_Widget(
                          Text: '${UserSharedPref.getUsername()}',
                          fieldWidth: 92.27.w,
                          RegExp: r'^.{5,}$',
                          validateText: "يرجى ادخال اسم صحيح",
                          RegExpText: 'يرجى ادخال اكثر من 5 خانات للأسم',
                          textSize: 16,
                          controller: fullNameEditingController
                            ..text = '${UserSharedPref.getUsername()}',
                          leftIcon: false,
                          textFieldColor: SystemColors.whiteBackgroundColor,
                          elevation: 1,
                          rightIcon: true,
                          suffixIcon: 'assets/AccountIcon.png',
                        ),
                        SizedBox(
                          height: 3.79.h,
                        ),
                        TextField_Widget(
                          Text: "${UserSharedPref.getUserEmail()}",
                          fieldWidth: 92.27.w,
                          validateText: "يرجى ادخال عنوان بريد",
                          textSize: 16,
                          controller: emailEditingController
                            ..text = "${UserSharedPref.getUserEmail()}",
                          leftIcon: false,
                          textFieldColor: SystemColors.whiteBackgroundColor,
                          elevation: 1,
                          rightIcon: true,
                          suffixIcon: 'assets/EmailIcon.png',
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 3.79.h,
                  ),
                  InkWell(
                    onTap: () async {
                      if (_formKey.currentState!.validate() == true) {
                        await updateInfo();
                        _formKey.currentState!.reset();
                        setState(() {});
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('تم التغيير بنجاح')),
                        );
                      }
                    },
                    child: Button_widget(
                      buttonWidth: 92.27.w,
                      buttonText: 'تعديل',
                      activeButton1: true,
                      activeButtonColor: SystemColors.mainColor,
                      activeTextColor: SystemColors.whiteBackgroundColor,
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      }),
    );
  }

  Future updateInfo() async {
    await user?.updateDisplayName(fullNameEditingController.text);
    UserSharedPref.setUsername(fullNameEditingController.text);
    user = _auth.currentUser!;
  }

  // Future<bool> validateCurrentPassword(String password) async {
  //   return await validatePassword(password);
  // }

  // Future<bool> validatePassword(String password) async {
  //   var authCredentials =
  //       EmailAuthProvider.credential(email: user!.email!, password: password);
  //   try {
  //     var authResult =
  //         await user!.reauthenticateWithCredential(authCredentials);
  //     return authResult.user != null;
  //   } catch (e) {
  //     return false;
  //   }
  // }

  // Future<void> updatePassword(String password) async {
  //   if (confirmPasswordEditingController.text ==
  //       newPasswordEditingController.text) {
  //     user!.updatePassword(password);
  //     Fluttertoast.showToast(msg: "تم تغيير كلمة السر");
  //   } else {
  //     Fluttertoast.showToast(msg: 'كلمة السر الجديدة غير متشابهة');
  //   }
  // }
}
