// ignore_for_file: deprecated_member_use, use_build_context_synchronously

import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/home_Screen.dart';
import 'package:tech_app_v1/Widgets/PleaseWaitDialog.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/backContainer_widget.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/Widgets/popUp_widget.dart';
import 'package:tech_app_v1/Widgets/text_field_widget.dart';
import 'package:tech_app_v1/services/userServices.dart';
import 'package:tech_app_v1/userModel/user_models.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class UserOrderScreen extends StatefulWidget {
  const UserOrderScreen({Key? key}) : super(key: key);

  @override
  State<UserOrderScreen> createState() => _UserOrderScreenState();
}

class _UserOrderScreenState extends State<UserOrderScreen> {
  final _auth = FirebaseAuth.instance;
  //formKey
  final _userOrderForm = GlobalKey<FormState>();

  //Controller
  final aboutJob = TextEditingController();
  final jobLocation = TextEditingController();

  //For Image Upload and Image Crop

  // Post Images and Videos*************************************************************************************************//

  List<PickedFile> images = [];
  List<String> userOrderImagesURL = [];

  Future<void> uploadImages() async {
    for (var i = 0; i < images.length; i++) {
      Reference ref = FirebaseStorage.instance
          .ref()
          .child('User_Orders/${images[i].path}.png');
      final File file = File.fromUri(Uri.parse(images[i].path));
      await ref.putFile(file);

      String downloadURL = await ref.getDownloadURL();

      setState(() {
        userOrderImagesURL.add(downloadURL);
      });
    }
  }

  Future<void> pickImages() async {
    final List<PickedFile>? pickedImages = await ImagePicker().getMultiImage();
    if (pickedImages == null) return;
    images.addAll(pickedImages);
    setState(() {});
  }
//*********************************************************************************************************************//

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Sizer(builder: (context, orientation, deviceType) {
        return Scaffold(
          backgroundColor: SystemColors.whiteBackgroundColor,
          body: GestureDetector(
            onTap: () {
              FocusManager.instance.primaryFocus?.unfocus();
            },
            child: SingleChildScrollView(
              child: Form(
                key: _userOrderForm,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    AppBar_Widget(
                        titleText: 'اضافة طلب',
                        rightIcon: 'assets/backArrow.png',
                        appBarheight: SystemSize.appBarheight.h,
                        navigateTo: home_Screen()),
                    SizedBox(
                      height: 3.57.h,
                    ),
                    SizedBox(
                      height: 4.87.h,
                      width: 51.w,
                      child: Text(
                        'يمكنك اضافه تفاصيل طلبك ليتم عرضه علي مؤدى الخدمات',
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.center,
                        style: SystemFont.mainFont14W400,
                      ),
                    ),
                    SizedBox(
                      height: 5.h,
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 3.86.w),
                        child: Text(
                          'نوع الخدمه',
                          style: GoogleFonts.almarai(
                              fontSize: 17,
                              fontWeight: FontWeight.w400,
                              color: SystemColors.mainColor,
                              wordSpacing: 1),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 1.79.h,
                    ),
                    backContainer_widget(
                      height: 14.17.h,
                      width: 92.27.w,
                      color: SystemColors.whiteBackgroundColor,
                      elevation: 1,
                      radius: 16,
                      child: Stack(
                        children: [
                          Center(
                            child: TextField_Widget(
                                controller: aboutJob,
                                leftIcon: false,
                                fieldHeight: 0.1059,
                                errorHeight: 0.1059,
                                maxHeight: 0.1059,
                                maxLines: 3,
                                verticalContentPadding: 70,
                                horizontalContentPadding: 70,
                                textFieldColor: SystemColors.whiteBackgroundColor,
                                Text: '... اكتب الوصف التفصيلي للخدمه هنا',
                                fieldWidth: 84.5.w,
                                textSize: 14),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 2.68.h),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 3.86.w),
                        child: Text(
                          'اضافه العنوان',
                          style: GoogleFonts.almarai(
                              fontSize: 17,
                              fontWeight: FontWeight.w400,
                              color: SystemColors.mainColor,
                              wordSpacing: 1),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 1.79.h,
                    ),
                    backContainer_widget(
                      height: 10.25.h,
                      width: 92.27.w,
                      color: SystemColors.whiteBackgroundColor,
                      elevation: 1,
                      radius: 16,
                      child: TextField_Widget(
                        leftIcon: false,
                        controller: jobLocation,
                        maxHeight: 6.25.h,
                        errorHeight: 6.25.h,
                        fieldHeight: 6.25.h,
                        Text: 'اضف العنوان المراد تاديه الخدمه فيه',
                        fieldWidth: 92.27.w,
                        textSize: 14,
                        textFieldColor: SystemColors.whiteBackgroundColor,
                      ),
                    ),
                    SizedBox(
                      height: 2.68.h,
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 3.86.w),
                        child: Text(
                          'اضافه صور او فديو تعريفي',
                          style: GoogleFonts.almarai(
                              fontSize: 17,
                              fontWeight: FontWeight.w400,
                              color: SystemColors.mainColor,
                              wordSpacing: 1),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 0.5.h,
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: EdgeInsets.only(left: 3.86.w),
                        child: Text(
                          "(Long press the image you want to delete)",
                          style: GoogleFonts.almarai(
                              fontSize: 13,
                              fontWeight: FontWeight.w400,
                              color: SystemColors.textColorBlack,
                              wordSpacing: 1),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 1.79.h,
                    ),
                    images.isEmpty
                        ? backContainer_widget(
                            height: 19.96.h,
                            width: 92.27.w,
                            color: SystemColors.whiteBackgroundColor,
                            DottedBorderStrokePattern: 5,
                            DottedBorderColor: SystemColors.mainColor,
                            radius: 16,
                            DottedBorderStrokeWidth: 1,
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(top: 2.68.h),
                                    child: Image.asset("assets/uploadIcon.png"),
                                  ),
                                  SizedBox(
                                    height: 2.h,
                                  ),
                                  Text(
                                    'اضف ملفاتك من هنا',
                                    style: SystemFont.mainFont14W400,
                                  ),
                                  SizedBox(
                                    height: 1.79.h,
                                  ),
                                  InkWell(
                                    onTap: () {
                                      pickImages();
                                    },
                                    child: Text(
                                      'بحث',
                                      style: SystemFont.mainFont14W400Blue,
                                    ),
                                  )
                                ]),
                          )
                        : Column(
                            children: [
                              backContainer_widget(
                                height: 19.96.h,
                                width: 92.27.w,
                                color: SystemColors.whiteBackgroundColor,
                                DottedBorderStrokePattern: 5,
                                DottedBorderColor: SystemColors.mainColor,
                                radius: 16,
                                DottedBorderStrokeWidth: 1,
                                child: Padding(
                                  padding: EdgeInsets.all(2.0.w),
                                  child: GridView.builder(
                                    itemCount: images.length,
                                    gridDelegate:
                                        SliverGridDelegateWithFixedCrossAxisCount(
                                            crossAxisCount: 3,
                                            mainAxisSpacing: 0.01 * h,
                                            crossAxisSpacing: 0.01 * h),
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return ClipRRect(
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(8)),
                                        child: InkWell(
                                          onLongPress: () {
                                            setState(() {
                                              images.removeAt(index);
                                            });
                                          },
                                          child: Image.file(
                                              File(images[index].path),
                                              fit: BoxFit.cover),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 1.79.h,
                              ),
                              Button_widget(
                                Function: () {
                                  pickImages();
                                },
                                buttonWidth: 90.26.w,
                                buttonText: 'اضف المزيد',
                                activeButtonColor: SystemColors.mainColor,
                                activeButton1: true,
                                activeTextColor: SystemColors.whiteBackgroundColor,
                              )
                            ],
                          ),
                    SizedBox(
                      height: 2.68.h,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        InkWell(
                          onTap: () {
                            navigate(context, home_Screen(), false);
                          },
                          child: Button_widget(
                            buttonWidth: 44.2.w,
                            buttonText: 'الغاء',
                            inactiveButtonColor: SystemColors.whiteBackgroundColor,
                            borderColor: SystemColors.mainColor,
                            activeButton1: true,
                            activeButtonColor: SystemColors.mainColor,
                            activeTextColor: SystemColors.whiteBackgroundColor,
                          ),
                        ),
                        InkWell(
                          onTap: () async {
                            if (_userOrderForm.currentState!.validate() ==
                                true) {
                              showDialog(
                                  context: context,
                                  barrierDismissible: false,
                                  builder: (
                                    BuildContext context,
                                  ) =>
                                      PleaseWaitWidget());
                              await uploadImages();
                              Navigator.of(context).pop();
                              await postOfferDetailsToFirestore();

                              showDialog(
                                context: context,
                                barrierDismissible: false,
                                builder: (BuildContext context) =>
                                    popUp_Widget(context),
                              );
                            }
                          },
                          child: Button_widget(
                            buttonWidth: 44.2.w,
                            buttonText: 'اضف',
                            inactiveButtonColor: SystemColors.whiteBackgroundColor,
                            borderColor: SystemColors.mainColor,
                            activeButton1: false,
                            activeButtonColor: SystemColors.mainColor,
                            activeTextColor: SystemColors.whiteBackgroundColor,
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  postOfferDetailsToFirestore() async {
    // calling our firestore
    // calling our user model
    // sedning these values

    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    User? user = _auth.currentUser;

    UserModel userModel = UserModel();

    // writing all the values

    userModel.uid = user!.uid;
    userModel.FullName = user.displayName;
    userModel.email = user.email;
    userModel.aboutJob = aboutJob.text;
    userModel.jobLocation = jobLocation.text;
    userModel.orderPics = userOrderImagesURL;

    await firebaseFirestore.collection("Admin_Approval_UserOrders").add(userModel.toMap());
  }
}
