import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/userEditAccountScreen.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/backContainer_widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';
import 'package:user_profile_avatar/user_profile_avatar.dart';
import 'package:tech_app_v1/services/userServices.dart';

class UserAccount extends StatefulWidget {
  const UserAccount({Key? key}) : super(key: key);

  @override
  State<UserAccount> createState() => _UserAccountState();
}

class _UserAccountState extends State<UserAccount> {
  User? user = FirebaseAuth.instance.currentUser;
  String? username;
  String? profilePic;
  String? email;
  @override
  void initState() {
    super.initState();
    username = UserSharedPref.getUsername();
    profilePic = UserSharedPref.getProfilePic();
    email = UserSharedPref.getUserEmail();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Sizer(
        builder: (context, orientation, deviceType) {
          return Scaffold(
            backgroundColor: SystemColors.whiteBackgroundColor,
            body: Column(
              children: [
                AppBar_Widget(
                  titleText: 'حسابي',
                  appBarheight: SystemSize.appBarheight.h,
                  leftIcon: true,
                  leadingTextFunction: () {
                    navigate(context, userEditAccount(), true);
                  },
                ),
                SizedBox(
                  height: 3.46.h,
                ),
                Padding(
                  padding: EdgeInsets.only(right: 3.86.w),
                  child: Align(
                    alignment: Alignment.topRight,
                    child: Stack(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  '$username',
                                  style: SystemFont.mainFont20W700,
                                ),
                                SizedBox(
                                  height: 0.7.h,
                                ),
                                Text(
                                  user!.uid.substring(0, 10),
                                  style: GoogleFonts.almarai(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w400,
                                      color: const Color(0xFF494949)),
                                )
                              ],
                            ),
                            SizedBox(
                              width: 2.5.w,
                            ),
                            UserProfileAvatar(
                              avatarUrl: '${UserSharedPref.getProfilePic()}',
                              radius: 55,
                              isActivityIndicatorSmall: false,
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.68.h,
                ),
                backContainer_widget(
                  height: 6.25.h,
                  width: 92.27.w,
                  color: SystemColors.whiteBackgroundColor,
                  elevation: 1,
                  radius: 16,
                  withIcon: true,
                  rowIcon: 'assets/AccountIcon.png',
                  rowText: '$username',
                ),
                SizedBox(
                  height: 3.79.h,
                ),
                backContainer_widget(
                  height: 6.25.h,
                  width: 92.27.w,
                  color: SystemColors.whiteBackgroundColor,
                  elevation: 1,
                  radius: 16,
                  withIcon: true,
                  rowIcon: 'assets/EmailIcon.png',
                  rowText: "${UserSharedPref.getUserEmail()}",
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
