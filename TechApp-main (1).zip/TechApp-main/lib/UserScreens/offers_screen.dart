// ignore_for_file: camel_case_types

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';
import 'package:tech_app_v1/Widgets/providerOffer_widget.dart';

class offers_Screen extends StatefulWidget {
  const offers_Screen({Key? key}) : super(key: key);

  @override
  State<offers_Screen> createState() => _offers_ScreenState();
}

class _offers_ScreenState extends State<offers_Screen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Sizer(builder: (context, orientation, deviceType) {
        return Scaffold(
            body: SingleChildScrollView(
              child: Column(
                children: [
                  AppBar_Widget(
                    titleText: 'العروض',
                    appBarheight: SystemSize.appBarheight.h,
                    icon: false,
                  ),
                  SizedBox(
                    height: 3.0.h,
                  ),
                  Padding(
                    padding: EdgeInsets.only(right: 3.86.w),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'العروض المقدمه من مقدمي الخدمه',
                        style: GoogleFonts.almarai(
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            color: SystemColors.mainColor,
                            wordSpacing: 1),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 1.79.h,
                  ),
                  const providerOffer_widget(),
                  SizedBox(
                    height: 1.79.h,
                  ),
                  const providerOffer_widget(),
                ],
              ),
            ),
            resizeToAvoidBottomInset: false,
            extendBody: true,
            floatingActionButton: const navBar_widget()
                .floatingActionButton(const UserOrderScreen(), context),
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerDocked,
            bottomNavigationBar: const navBar_widget());
      }),
    );
  }
}
