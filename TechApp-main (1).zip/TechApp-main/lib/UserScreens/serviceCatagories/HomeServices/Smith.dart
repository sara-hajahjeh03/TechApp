import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/UserScreens/viewProviderProfile.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';
import 'package:tech_app_v1/Widgets/providerInfoBox.dart';
import 'package:tech_app_v1/services/userServices.dart';

final CollectionReference Smith =
    FirebaseFirestore.instance.collection('Provider_ Smith');

class Smith_Get_Info extends StatefulWidget {
  final _auth = FirebaseAuth.instance;
  final String documentId;
  Smith_Get_Info({Key? key, required this.documentId}) : super(key: key);

  @override
  State<Smith_Get_Info> createState() => _Smith_Get_InfoState();
}

class _Smith_Get_InfoState extends State<Smith_Get_Info> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    return FutureBuilder<DocumentSnapshot>(
      future: Smith.doc(widget.documentId).get(),
      builder: ((context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          Map<String, dynamic> data =
              snapshot.data!.data() as Map<String, dynamic>;

          return ProviderInfoBox_Widget(
            name: '${data['FullName']}',
            occupation: '${data['Occupation']}',
            city: data['City'],
          );
        }
        return Container(
          height: 0.173 * h,
          width: 0.9227 * w,
          color: Colors.white,
          child: const Center(
            child: CircularProgressIndicator(color: SystemColors.mainColor),
          ),
        );
      }),
    );
  }
}

class houseServices_smith extends StatefulWidget {
  const houseServices_smith({Key? key}) : super(key: key);

  @override
  State<houseServices_smith> createState() => _houseServices_smithState();
}

class _houseServices_smithState extends State<houseServices_smith> {
  // document IDs
  List<String> docIDs = [];
// get docIDS
  Future getDocId() async {
    await FirebaseFirestore.instance.collection('Provider_ Smith').get().then(
          (snapshot) => snapshot.docs.forEach((document) {
            docIDs.add(document.reference.id);
          }),
        );
  }

  late Future<dynamic> dataFuture;
  @override
  void initState() {
    super.initState();
    dataFuture = getDocId();
  }

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return Scaffold(
          backgroundColor: SystemColors.whiteBackgroundColor,
          body: Column(
            children: [
              AppBar_Widget(
                titleText: 'اعمال الحدادة',
                appBarheight: SystemSize.appBarheight.h,
                rightIcon: 'assets/backArrow.png',
              ),
              Expanded(
                child: FutureBuilder(
                    future: dataFuture,
                    builder: (context, snapshot) {
                      return ListView.builder(
                          itemCount: docIDs.length,
                          itemBuilder: (context, index) {
                            return ListTile(
                              title: Smith_Get_Info(documentId: docIDs[index]),
                              onTap: () {
                                navigate(
                                    context,
                                    ViewProviderProfile(
                                      documentId: docIDs[index],
                                      occupation: "smith",
                                    ),
                                    true);
                              },
                            );
                          });
                    }),
              )
            ],
          ),
          extendBody: true,
          floatingActionButton: const navBar_widget()
              .floatingActionButton(const UserOrderScreen(), context),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerDocked,
          bottomNavigationBar: const navBar_widget());
    });
  }
}
