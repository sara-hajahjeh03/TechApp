import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/home_Screen.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/CarServices/Mechanic.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/CarServices/Oil.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/CarServices/carWash.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/choiceButton_widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';

class carServices_Screen extends StatefulWidget {
  const carServices_Screen({Key? key}) : super(key: key);

  @override
  State<carServices_Screen> createState() => _carServices_ScreenState();
}

class _carServices_ScreenState extends State<carServices_Screen> {
  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (context, orientation, deviceType) {
        return SafeArea(
          child: Scaffold(
              backgroundColor: SystemColors.whiteBackgroundColor,
              body: Column(
                children: [
                  AppBar_Widget(
                    titleText: 'خدمات السيارات',
                    rightIcon: 'assets/backArrow.png',
                    appBarheight: SystemSize.appBarheight.h,
                    navigateTo: home_Screen(),
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ChoiceButton(
                        boxHeight: 16.29.h,
                        boxWidth: 40.2.w,
                        icon: 'assets/MechanicIcon.png',
                        iconSize: 60,
                        text: 'ميكانيكي',
                        iconPadding: 2.23.h,
                        iconOnPressed: () {},
                        boxColor: SystemColors.whiteBackgroundColor,
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const carService_mechanic(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                true, //if you want to disable back feature set to false
                          );
                        },
                      ),
                      ChoiceButton(
                        boxHeight: 16.29.h,
                        boxWidth: 40.2.w,
                        icon: 'assets/carWashIcon.png',
                        iconSize: 60,
                        text: 'غسيل السيارات',
                        iconPadding: 2.23.h,
                        iconOnPressed: () {},
                        boxColor: SystemColors.whiteBackgroundColor,
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const carService_carWash(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                true, //if you want to disable back feature set to false
                          );
                        },
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 2.785.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: 16.29.h,
                        width: 40.2.w,
                      ),
                      ChoiceButton(
                        boxHeight: 16.29.h,
                        boxWidth: 40.2.w,
                        icon: 'assets/OilRe-fillicon.png',
                        iconSize: 60,
                        text: 'توصيل البنزين',
                        iconPadding: 2.23.h,
                        iconOnPressed: () {},
                        boxColor: SystemColors.whiteBackgroundColor,
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const carService_oil(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                true, //if you want to disable back feature set to false
                          );
                        },
                      ),
                    ],
                  )
                ],
              ),
              extendBody: true,
              floatingActionButton: const navBar_widget()
                  .floatingActionButton(const UserOrderScreen(), context),
              floatingActionButtonLocation:
                  FloatingActionButtonLocation.centerDocked,
              bottomNavigationBar: const navBar_widget()),
        );
      },
    );
  }
}
