import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';
import 'package:tech_app_v1/Widgets/providerInfoBox.dart';

final CollectionReference Painter =
    FirebaseFirestore.instance.collection('Provider_ painter');

class Painter_Get_Info extends StatefulWidget {
  final _auth = FirebaseAuth.instance;
  final String documentId;
  Painter_Get_Info({Key? key, required this.documentId}) : super(key: key);

  @override
  State<Painter_Get_Info> createState() => _Painter_Get_InfoState();
}

class _Painter_Get_InfoState extends State<Painter_Get_Info> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    return FutureBuilder<DocumentSnapshot>(
      future: Painter.doc(widget.documentId).get(),
      builder: ((context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          Map<String, dynamic> data =
              snapshot.data!.data() as Map<String, dynamic>;
          return ProviderInfoBox_Widget(
            name: '${data['FullName']}',
            occupation: '${data['Occupation']}',
            city: data['City'],
          );
        }
        return Container(
          height: 0.173 * h,
          width: 0.9227 * w,
          color: Colors.white,
          child: const Center(
            child: CircularProgressIndicator(color: SystemColors.mainColor),
          ),
        );
      }),
    );
  }
}

class houseServices_painter extends StatefulWidget {
  const houseServices_painter({Key? key}) : super(key: key);

  @override
  State<houseServices_painter> createState() => _houseServices_painterState();
}

class _houseServices_painterState extends State<houseServices_painter> {
  // document IDs
  List<String> docIDs = [];
// get docIDS
  Future getDocId() async {
    await FirebaseFirestore.instance.collection('Provider_ painter').get().then(
          (snapshot) => snapshot.docs.forEach((document) {
            docIDs.add(document.reference.id);
          }),
        );
  }

  late Future<dynamic> dataFuture;
  @override
  void initState() {
    super.initState();
    dataFuture = getDocId();
  }

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return Scaffold(
          backgroundColor: SystemColors.whiteBackgroundColor,
          body: Column(
            children: [
              AppBar_Widget(
                titleText: 'اعمال الدهان',
                appBarheight: SystemSize.appBarheight.h,
                rightIcon: 'assets/backArrow.png',
              ),
              Expanded(
                child: FutureBuilder(
                    future: dataFuture,
                    builder: (context, snapshot) {
                      return ListView.builder(
                          itemCount: docIDs.length,
                          itemBuilder: (context, index) {
                            return ListTile(
                              title:
                                  Painter_Get_Info(documentId: docIDs[index]),
                            );
                          });
                    }),
              )
            ],
          ),
          extendBody: true,
          floatingActionButton: const navBar_widget()
              .floatingActionButton(const UserOrderScreen(), context),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerDocked,
          bottomNavigationBar: const navBar_widget());
    });
  }
}
