import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:readmore/readmore.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/backContainer_widget.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/Widgets/comments_Widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';
import 'package:tech_app_v1/Widgets/providerInfoBox.dart';

class ViewProviderProfile extends StatefulWidget {
  final String? documentId;
  final String? occupation;

  ViewProviderProfile({Key? key, this.documentId, this.occupation})
      : super(key: key);

  @override
  State<ViewProviderProfile> createState() => _ViewProviderProfileState();
}

class _ViewProviderProfileState extends State<ViewProviderProfile> {
  @override
  final CollectionReference ElectricianCollection =
      FirebaseFirestore.instance.collection('Provider_Electrician');
  final CollectionReference plumberCollection =
      FirebaseFirestore.instance.collection('Provider_Plumber');
  final CollectionReference smithCollection =
      FirebaseFirestore.instance.collection('Provider_ Smith');
  final CollectionReference carpenterCollection =
      FirebaseFirestore.instance.collection('Provider_Carpenter');

  Widget build(BuildContext context) {
    return SafeArea(
      child: Sizer(
        builder: (context, orientation, deviceType) {
          return Scaffold(
            backgroundColor: SystemColors.whiteBackgroundColor,
            body: FutureBuilder<DocumentSnapshot>(
                future: (widget.occupation == 'electric')
                    ? ElectricianCollection.doc(widget.documentId).get()
                    : (widget.occupation == 'plumber')
                        ? plumberCollection.doc(widget.documentId).get()
                        : (widget.occupation == 'smith')
                            ? smithCollection.doc(widget.documentId).get()
                            : (widget.occupation == 'carpenter')
                                ? carpenterCollection
                                    .doc(widget.documentId)
                                    .get()
                                : null,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.done) {
                    Map<String, dynamic> data =
                        snapshot.data!.data() as Map<String, dynamic>;

                    return SingleChildScrollView(
                      child: Column(
                        children: [
                          AppBar_Widget(
                            titleText: 'الملف الشخصي',
                            rightIcon: 'assets/backArrow.png',
                            appBarheight: SystemSize.appBarheight.h,
                          ),
                          SizedBox(
                            height: 4.46.h,
                          ),
                          ProviderInfoBox_Widget(
                            name: '${data['FullName']}',
                            occupation: '${data['Occupation']}',
                            userUID: '${data['uid']}',
                            city: data['City'],
                            elevation: 1,
                            profile: false,
                          ),
                          SizedBox(
                            height: 2.68.h,
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 3.86.w),
                            child: Align(
                              alignment: Alignment.centerRight,
                              child: Text(
                                'نبذه عني',
                                style: GoogleFonts.almarai(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  color: SystemColors.mainColor,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 1.79.h,
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 3.86.w),
                            child: Align(
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                width: 75.w,
                                child: ReadMoreText(
                                  "${data['About']}",
                                  style: GoogleFonts.almarai(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: SystemColors.textColorBlack,
                                    wordSpacing: 2,
                                  ),
                                  trimLines: 3,
                                  colorClickableText: SystemColors.mainColor,
                                  trimMode: TrimMode.Line,
                                  trimCollapsedText: 'المزيد',
                                  trimExpandedText: 'اخفاء',
                                  textDirection: TextDirection.rtl,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 2.68.h,
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 3.86.w),
                            child: Align(
                              alignment: Alignment.centerRight,
                              child: Text(
                                'الأعمال السابقة',
                                style: GoogleFonts.almarai(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  color: SystemColors.mainColor,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 1.79.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              backContainer_widget(
                                height: 13.93.h,
                                width: 28.02.w,
                                color: SystemColors.greyColor,
                                radius: 16,
                              ),
                              backContainer_widget(
                                height: 13.93.h,
                                width: 28.02.w,
                                color: SystemColors.greyColor,
                                radius: 16,
                              ),
                              backContainer_widget(
                                height: 13.93.h,
                                width: 28.02.w,
                                color: SystemColors.greyColor,
                                radius: 16,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 1.79.h,
                          ),
                          backContainer_widget(
                            height: 16.41.h,
                            width: 92.27.w,
                            color: SystemColors.greyColor,
                            radius: 16,
                          ),
                          SizedBox(
                            height: 4.0.h,
                          ),
                          Button_widget(
                            buttonWidth: 92.27.w,
                            buttonText: 'اظهار المزيد',
                            inactiveButtonColor:
                                SystemColors.whiteBackgroundColor,
                            borderColor: SystemColors.mainColor,
                            inactiveTextColor: SystemColors.mainColor,
                          ),
                          SizedBox(
                            height: 1.79.h,
                          ),
                          CommentsWidget(height: 17.6.h, width: 92.27.w),
                          SizedBox(
                            height: 2.68.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Button_widget(
                                buttonWidth: 44.2.w,
                                buttonText: 'اظهار كل التعليقات',
                                activeButton1: false,
                                inactiveTextColor: SystemColors.mainColor,
                                borderColor: SystemColors.mainColor,
                              ),
                              Button_widget(
                                buttonWidth: 44.2.w,
                                buttonText: 'اضافه تعليق',
                                activeButton1: true,
                                activeButtonColor: SystemColors.mainColor,
                                activeTextColor:
                                    SystemColors.whiteBackgroundColor,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 13.69.h,
                          ),
                        ],
                      ),
                    );
                  }
                  return const Center(child: CircularProgressIndicator());
                }),
          );
        },
      ),
    );
  }
}
