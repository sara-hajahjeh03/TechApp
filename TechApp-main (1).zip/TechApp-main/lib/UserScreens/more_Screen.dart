// ignore_for_file: use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/SharedScreens/choice_Screen.dart';
import 'package:tech_app_v1/SharedScreens/editPasswordScreen.dart';
import 'package:tech_app_v1/UserScreens/userAccount.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/backContainer_widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';
import 'package:tech_app_v1/services/userServices.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Sizer(
        builder: (context, orientation, deviceType) {
          return Scaffold(
              backgroundColor: SystemColors.whiteBackgroundColor,
              body: Column(
                children: [
                  AppBar_Widget(
                    titleText: 'المزيد',
                    appBarheight: SystemSize.appBarheight.h,
                    icon: false,
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  backContainer_widget(
                    height: 6.25.h,
                    width: 92.27.w,
                    color: SystemColors.whiteBackgroundColor,
                    radius: 8,
                    elevation: 1,
                    withIcon: true,
                    rowText: 'حسابي',
                    rowIcon: 'assets/MyAccountIcon.png',
                    function: () {
                      navigate(context, UserAccount(), true);
                    },
                  ),
                  SizedBox(
                    height: 3.79.h,
                  ),
                  backContainer_widget(
                    function: () {
                      navigate(context, editPasswordScreen(), true);
                    },
                    height: 6.25.h,
                    width: 92.27.w,
                    color: SystemColors.whiteBackgroundColor,
                    radius: 8,
                    elevation: 1,
                    withIcon: true,
                    rowText: 'تغيير كلمة السر',
                    rowIcon: 'assets/langIcon.png',
                  ),
                  SizedBox(
                    height: 3.79.h,
                  ),
                  backContainer_widget(
                    height: 6.25.h,
                    width: 92.27.w,
                    color: SystemColors.whiteBackgroundColor,
                    radius: 8,
                    elevation: 1,
                    withIcon: true,
                    rowText: 'اللغة',
                    rowIcon: 'assets/langIcon.png',
                  ),
                  SizedBox(
                    height: 3.79.h,
                  ),
                  backContainer_widget(
                    height: 6.25.h,
                    width: 92.27.w,
                    color: SystemColors.whiteBackgroundColor,
                    radius: 8,
                    elevation: 1,
                    withIcon: true,
                    rowText: 'عن التطبيق',
                    rowIcon: 'assets/AboutIcon.png',
                  ),
                  SizedBox(
                    height: 3.79.h,
                  ),
                  backContainer_widget(
                    height: 6.25.h,
                    width: 92.27.w,
                    color: SystemColors.whiteBackgroundColor,
                    radius: 8,
                    elevation: 1,
                    withIcon: true,
                    rowText: 'التواصل مع الدعم الفني',
                    rowIcon: 'assets/contactUsIcon.png',
                  ),
                  SizedBox(
                    height: 3.79.h,
                  ),
                  InkWell(
                    onTap: () {
                      logout(context);
                    },
                    child: backContainer_widget(
                      height: 6.25.h,
                      width: 92.27.w,
                      color: SystemColors.whiteBackgroundColor,
                      radius: 8,
                      elevation: 1,
                      withIcon: true,
                      rowText: 'تسجيل الخروج',
                      rowIcon: 'assets/logOutIcon.png',
                    ),
                  ),
                ],
              ),
              resizeToAvoidBottomInset: false,
              extendBody: true,
              floatingActionButton: const navBar_widget()
                  .floatingActionButton(const UserOrderScreen(), context),
              floatingActionButtonLocation:
                  FloatingActionButtonLocation.centerDocked,
              bottomNavigationBar: const navBar_widget());
        },
      ),
    );
  }

  Future<void> logout(BuildContext context) async {
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    final _auth = FirebaseAuth.instance;
    final userRef =
        firebaseFirestore.collection('users').doc(_auth.currentUser!.uid);

    await userRef.update({'token': ''});
    UserSharedPref.setUserLogin(false);

    await FirebaseAuth.instance.signOut();

    navigate(context, choice_Screen(), false);
  }
}
