import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/houseServices_Screen.dart';
import 'package:tech_app_v1/UserScreens/offers_screen.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/HomeServices/carServices_Screen.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/choiceButton_widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';
import 'package:tech_app_v1/Widgets/offersScroll_widget.dart';
import 'package:tech_app_v1/Widgets/providerInfoBox.dart';
import 'package:tech_app_v1/Widgets/providerOfferBox_widget.dart';
import 'package:tech_app_v1/Widgets/searchBar_widget.dart' as SearchBar;
import 'package:tech_app_v1/services/userServices.dart';

class home_Screen extends StatefulWidget {
  home_Screen({Key? key}) : super(key: key);

  @override
  State<home_Screen> createState() => _home_ScreenState();
}

class _home_ScreenState extends State<home_Screen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Sizer(builder: (context, orientation, deviceType) {
        return GestureDetector(
          onTap: () {
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
              backgroundColor: Colors.white,
              body: SingleChildScrollView(
                child: SizedBox(
                  height: 100.h,
                  width: 100.w,
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        AppBar_Widget(
                          rightIcon: 'assets/backArrow.png',
                          titleText: 'الصفحة الرئيسية',
                          appBarheight: SystemSize.appBarheight.h,
                          navigateTo: home_Screen(),
                          icon: false,
                        ),
                        SizedBox(
                          height: 3.35.h,
                        ),
                        const SearchBar.SearchBar(hintText: 'كهربائي...'),
                        SizedBox(
                          height: 2.68.h,
                        ),
                        Padding(
                          padding: EdgeInsets.only(right: 3.865.w),
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              'احدث العروض',
                              style: SystemFont.tajawalS16W700,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 1.79.h,
                        ),
                        OffersScroll_widget(
                          height: 16.853.h,
                          width: 71.98.w,
                          spacing: 3.865.w,
                          spaceUnderImage: 1.786.h,
                          dotHeight: 1.12.h,
                          dotWidth: 2.42.w,
                        ),
                        SizedBox(
                          height: 2.68.h,
                        ),
                        Padding(
                          padding: EdgeInsets.only(right: 3.865.w),
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              'الخدمات',
                              style: SystemFont.tajawalS16W700,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 1.786.h,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ChoiceButton(
                              boxHeight: 14.73.h,
                              boxWidth: 44.2.w,
                              icon: 'assets/homeServices.png',
                              text: 'الخدمات المنزليه',
                              textSize: 16,
                              iconPadding: 2.h,
                              boxColor: SystemColors.whiteBackgroundColor,
                              iconOnPressed: () {},
                              onTap: () {
                                navigate(context, HouseService(), true);
                              },
                            ),
                            SizedBox(
                              width: 3.865.w,
                            ),
                            ChoiceButton(
                              boxHeight: 14.73.h,
                              boxWidth: 44.2.w,
                              icon: 'assets/carServices.png',
                              text: 'خدمات السيارات',
                              textSize: 16,
                              iconPadding: 2.h,
                              boxColor: SystemColors.whiteBackgroundColor,
                              iconOnPressed: () {},
                              onTap: () {
                                navigate(context, carServices_Screen(), true);
                              },
                            ),
                          ],
                        ),
                        SizedBox(height: 2.68.h),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(left: 3.865.w),
                              child: InkWell(
                                onTap: () {
                                  navigate(context, offers_Screen(), true);
                                },
                                child: Text(
                                  'اظهار الكل',
                                  style: SystemFont.mainFont14W400,
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(right: 3.865.w),
                              child: Align(
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    'العروض المقدمة',
                                    style: SystemFont.tajawalS16W700,
                                  )),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 1.786.h,
                        ),
                        const ProviderOfferBox_widget(),
                        SizedBox(
                          height: 4.24.h,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(left: 3.865.w),
                              child: Text(
                                'اظهار الكل',
                                style: SystemFont.mainFont14W400,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(right: 3.865.w),
                              child: Align(
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    'أفضل مؤديين خدمة',
                                    style: SystemFont.tajawalS16W700,
                                  )),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 1.79.h,
                        ),
                        const ProviderInfoBox_Widget(),
                        SizedBox(
                          height: 1.79.h,
                        ),
                        const ProviderInfoBox_Widget(),
                        SizedBox(
                          height: 1.79.h,
                        ),
                        const ProviderInfoBox_Widget(),
                        SizedBox(
                          height: 13.79.h,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              resizeToAvoidBottomInset: false,
              extendBody: true,
              floatingActionButton: navBar_widget()
                  .floatingActionButton(UserOrderScreen(), context),
              floatingActionButtonLocation:
                  FloatingActionButtonLocation.centerDocked,
              bottomNavigationBar: navBar_widget()),
        );
      }),
    );
  }
}
