import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/UserScreens/home_Screen.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/HomeServices/Carpenter.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/HomeServices/Electrician.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/HomeServices/Painter.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/HomeServices/Plumber.dart';
import 'package:tech_app_v1/UserScreens/serviceCatagories/HomeServices/Smith.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/choiceButton_widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';

class HouseService extends StatefulWidget {
  const HouseService({Key? key}) : super(key: key);

  @override
  State<HouseService> createState() => _HouseServiceState();
}

class _HouseServiceState extends State<HouseService> {
  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (context, orientation, deviceType) {
        return SafeArea(
          child: Scaffold(
              backgroundColor: SystemColors.whiteBackgroundColor,
              body: Column(
                children: [
                  AppBar_Widget(
                    titleText: 'الخدمات المنزليه',
                    rightIcon: 'assets/backArrow.png',
                    appBarheight: SystemSize.appBarheight.h,
                    navigateTo: home_Screen(),
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ChoiceButton(
                        boxHeight: 16.29.h,
                        boxWidth: 40.2.w,
                        icon: 'assets/CarpenterIcon.png',
                        iconSize: 60,
                        text: 'اعمال النجاره',
                        iconPadding: 2.23.h,
                        iconOnPressed: () {},
                        boxColor: SystemColors.whiteBackgroundColor,
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const houseServices_carpenter(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                true, //if you want to disable back feature set to false
                          );
                        },
                      ),
                      ChoiceButton(
                        boxHeight: 16.29.h,
                        boxWidth: 40.2.w,
                        icon: 'assets/ElectricianIcon.png',
                        iconSize: 60,
                        text: 'اعمال الكهرباء',
                        iconPadding: 2.23.h,
                        iconOnPressed: () {},
                        boxColor: SystemColors.whiteBackgroundColor,
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const houseServices_electrician(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                true, //if you want to disable back feature set to false
                          );
                        },
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 2.785.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ChoiceButton(
                        boxHeight: 16.29.h,
                        boxWidth: 40.2.w,
                        icon: 'assets/PlumberIcon.png',
                        iconSize: 60,
                        text: 'اعمال السباكه',
                        iconPadding: 2.23.h,
                        iconOnPressed: () {},
                        boxColor: SystemColors.whiteBackgroundColor,
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const houseServices_plumber(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                true, //if you want to disable back feature set to false
                          );
                        },
                      ),
                      ChoiceButton(
                        boxHeight: 16.29.h,
                        boxWidth: 40.2.w,
                        icon: 'assets/SmithIcon.png',
                        iconSize: 60,
                        text: 'اعمال الحداده',
                        iconPadding: 2.23.h,
                        iconOnPressed: () {},
                        boxColor: SystemColors.whiteBackgroundColor,
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const houseServices_smith(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                true, //if you want to disable back feature set to false
                          );
                        },
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 2.785.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: 16.29.h,
                        width: 40.2.w,
                      ),
                      ChoiceButton(
                        boxHeight: 16.29.h,
                        boxWidth: 40.2.w,
                        icon: 'assets/PainterIcon.png',
                        iconSize: 60,
                        text: 'اعمال الدهان',
                        iconPadding: 2.23.h,
                        iconOnPressed: () {},
                        boxColor: SystemColors.whiteBackgroundColor,
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation1, animation2) =>
                                  const houseServices_painter(),
                              transitionDuration: Duration.zero,
                              reverseTransitionDuration: Duration.zero,
                            ),
                            (route) =>
                                true, //if you want to disable back feature set to false
                          );
                        },
                      ),
                    ],
                  )
                ],
              ),
              extendBody: true,
              floatingActionButton: const navBar_widget()
                  .floatingActionButton(const UserOrderScreen(), context),
              floatingActionButtonLocation:
                  FloatingActionButtonLocation.centerDocked,
              bottomNavigationBar: const navBar_widget()),
        );
      },
    );
  }
}
