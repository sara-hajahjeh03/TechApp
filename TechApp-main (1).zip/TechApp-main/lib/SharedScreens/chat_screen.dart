import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/SharedScreens/chatRoom_Screen.dart';
import 'package:tech_app_v1/UserScreens/userOrder_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/chatBox_widget.dart';
import 'package:tech_app_v1/Widgets/navBar_widget.dart';
import 'package:tech_app_v1/services/firebaseServices.dart';
import 'package:tech_app_v1/services/userServices.dart';
import 'package:intl/intl.dart' as intl;
import 'package:intl/date_symbol_data_local.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Sizer(builder: (context, orientation, deviceType) {
        return Scaffold(
            backgroundColor: SystemColors.whiteBackgroundColor,
            body: Column(
              children: [
                AppBar_Widget(
                  titleText: "الرسائل",
                  icon: false,
                  appBarheight: SystemSize.appBarheight.h,
                ),
                SizedBox(
                  height: 4.464285714.h,
                ),
                const Divider(
                  thickness: 1,
                ),
                Expanded(
                    child: FutureBuilder<List<dynamic>>(
                  future: getChatWithList(_auth.currentUser!.uid),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      // If an error occurred
                      return Text('Error: ${snapshot.error}');
                    } else if (snapshot.hasData) {
                      // If the future completed successfully and has data
                      final List chatRooms = snapshot.data!;
                      // Use the document IDs as needed
                      return ListView.builder(
                        itemCount: chatRooms.length,
                        itemBuilder: (context, index) {
                          final chatRoom = chatRooms[index];
                          final String documentId =
                              "${chatRoom['users'][0]}_${chatRoom['users'][1]}";
                          final String sentTo = chatRoom['sentToName'];
                          final String sender = chatRoom['senderName'];
                          final String sentToUID = chatRoom['users'][1];
                          final String lastMessage = chatRoom['lastMessage'];
                          final timestamp = chatRoom['lastMessageTime'];
                          final date = DateTime.fromMillisecondsSinceEpoch(
                              timestamp.millisecondsSinceEpoch);

                          initializeDateFormatting('ar', null);
                          var arabicDateFormat = intl.DateFormat("h:mm", 'en');
                          var amPm = intl.DateFormat("a", "ar");
                          final formattedTimeAMPM = amPm.format(date);
                          final formattedTime = arabicDateFormat.format(date);

                          return InkWell(
                            onTap: () {
                              navigate(
                                  context,
                                  ChatRoom(
                                    userUID: sentToUID,
                                    roomID: documentId,
                                    username:
                                        UserSharedPref.getUsername() == sender
                                            ? sentTo
                                            : sender,
                                  ),
                                  true);
                            },
                            child: ChatBoxWidget(
                              message: lastMessage,
                              name: UserSharedPref.getUsername() == sender
                                  ? sentTo
                                  : sender,
                              time: formattedTime,
                              amPm: formattedTimeAMPM,
                            ),
                          );
                        },
                      );
                    } else {
                      // Default case, if none of the above conditions are met
                      return const Text('No data available');
                    }
                  },
                )),
              ],
            ),
            resizeToAvoidBottomInset: false,
            extendBody: true,
            floatingActionButton: const navBar_widget()
                .floatingActionButton(UserOrderScreen(), context),
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerDocked,
            bottomNavigationBar: const navBar_widget());
      }),
    );
  }
}
