import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/messageBubble.dart';
import 'package:tech_app_v1/Widgets/text_field_widget.dart';
import 'package:tech_app_v1/services/firebaseServices.dart';
import 'package:tech_app_v1/services/userServices.dart';
import 'package:intl/intl.dart' as intl;

class ChatRoom extends StatefulWidget {
  final String? username;
  final String? userUID;
  final String? roomID;
  const ChatRoom({super.key, this.username, this.userUID, this.roomID = ' '});

  @override
  State<ChatRoom> createState() => _ChatRoomState();
}

class _ChatRoomState extends State<ChatRoom> {
  final _auth = FirebaseAuth.instance;

  late List<XFile> selectedImages;

  File? _imageFile;
  File? sentFile;
  String imageSentUrl = '';
  TextEditingController messageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Sizer(
        builder: (context, orientation, deviceType) {
          return Scaffold(
            backgroundColor: SystemColors.whiteBackgroundColor,
            body: Stack(
              children: [
                Padding(
                  padding: EdgeInsets.only(
                    left: _imageFile != null ? 0 : 3.8647343.w,
                    right: _imageFile != null ? 0 : 3.8647343.w,
                  ),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 4.464285714.h,
                      ),
                      SizedBox(
                        height: 6.696428571.h,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: () async {
                                if (await PermissionHandler
                                    .askPhoneCallPermission()) {}
                              },
                              child: SizedBox(
                                height: h * 0.026785714,
                                width: w * 0.057971014,
                                child: const Icon(Icons.phone_outlined),
                              ),
                            ),
                            SizedBox(
                              width: w * 0.134927536,
                            ),
                            SizedBox(
                              width: w * 0.458937198,
                              child: Text(
                                textAlign: TextAlign.end,
                                widget.username!,
                                style: GoogleFonts.almarai(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: SystemColors.textColorBlack,
                                    wordSpacing: 0),
                              ),
                            ),
                            SizedBox(
                              width: w * 0.024154589,
                            ),
                            SizedBox(
                              height: 6.696428571.h,
                              width: 14.492753623.w,
                              child: const CircleAvatar(
                                backgroundColor: SystemColors.mainColor,
                                child: Icon(Icons.headphones),
                              ),
                            ),
                            SizedBox(
                              width: w * 0.041062802,
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: SizedBox(
                                height: h * 0.026785714,
                                width: w * 0.057971014,
                                child: const Icon(Icons.arrow_forward),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: h * 0.01,
                      ),
                      SizedBox(
                        height: h * 0.0001,
                        child: const Divider(
                          thickness: 2,
                        ),
                      ),
                      Expanded(
                        child:
                            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                          stream: getMessageStream(widget.roomID!),
                          builder: (BuildContext context,
                              AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>>
                                  snapshot) {
                            if (!snapshot.hasData) {
                              return Center(child: CircularProgressIndicator());
                            }

                            final List<
                                    QueryDocumentSnapshot<Map<String, dynamic>>>
                                messages = snapshot.data!.docs;

                            return ListView.builder(
                              padding: EdgeInsets.only(bottom: h * 0.08),
                              reverse: true,
                              physics: BouncingScrollPhysics(),
                              itemCount: messages.length,
                              itemBuilder: (BuildContext context, int index) {
                                final QueryDocumentSnapshot<
                                        Map<String, dynamic>> messageSnapshot =
                                    messages[index];
                                final timestamp =
                                    messageSnapshot.data()['sentTime'];
                                final date =
                                    DateTime.fromMillisecondsSinceEpoch(
                                        timestamp.millisecondsSinceEpoch);
                                final formattedTime =
                                    intl.DateFormat.jm().format(date);

                                // Check if the message is an image
                                if (messageSnapshot.data()['messageType'] ==
                                    'image') {
                                  // Check if the image URL is available
                                  if (messageSnapshot.data()['imageUrl'] !=
                                      null) {
                                    // Image URL is available, update the MessageBubble with the URL
                                    return MessageBubble(
                                      isImage: true,
                                      imageFilePath: _imageFile ??
                                          File(
                                              "/data/user/0/com.example.tech_app_v1/cache/c448cda4-190d-488e-a52a-8a4e192a22588157746200167618344.jpg"),
                                      imagePath:
                                          messageSnapshot.data()['message'],
                                      isMe: messageSnapshot.data()['sentBy'] ==
                                          _auth.currentUser!.uid,
                                      message:
                                          messageSnapshot.data()['message'],
                                      time: formattedTime,
                                      // imageUrl:
                                      //     messageSnapshot.data()['imageUrl'],
                                    );
                                  } else {
                                    // Image URL is not available, display a placeholder or loading indicator
                                    return MessageBubble(
                                      isImage: true,
                                      imageFilePath: _imageFile ??
                                          File(
                                              "/data/user/0/com.example.tech_app_v1/cache/c448cda4-190d-488e-a52a-8a4e192a22588157746200167618344.jpg"),
                                      imagePath:
                                          messageSnapshot.data()['message'],
                                      isMe: messageSnapshot.data()['sentBy'] ==
                                          _auth.currentUser!.uid,
                                      message:
                                          'Image is being uploaded...', // Placeholder message
                                      time: formattedTime,
                                    );
                                  }
                                } else {
                                  // Message is not an image, display as text
                                  return MessageBubble(
                                    isImage: false,
                                    isMe: messageSnapshot.data()['sentBy'] ==
                                        _auth.currentUser!.uid,
                                    message: messageSnapshot.data()['message'],
                                    time: formattedTime,
                                  );
                                }
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                _imageFile != null
                    ? Container(
                        height: h,
                        width: w,
                        color: Colors.black,
                        child: Stack(children: [
                          Positioned.fill(
                              child:
                                  Image.file(_imageFile!, fit: BoxFit.cover)),
                          Padding(
                            padding:
                                EdgeInsets.only(top: h * 0.05, left: w * 0.01),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    _imageFile = null;
                                  });
                                },
                                child: Icon(
                                  Icons.close,
                                  size: h * 0.03,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              color: Colors.black.withOpacity(0.5),
                              padding: EdgeInsets.symmetric(
                                  horizontal: w * 0.03, vertical: h * 0.005),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  IconButton(
                                    onPressed: () {
                                      setState(() async {
                                        _imageFile =
                                            await ImageSelector.takePhoto();

                                        setState(() {});
                                      });
                                    },
                                    // ignore: prefer_const_constructors
                                    icon: Icon(Icons.camera_alt_rounded,
                                        color: Colors.white),
                                  ),
                                  InkWell(
                                    onTap: () async {
                                      sentFile = _imageFile;

                                      _imageFile = null;
                                      print(
                                          "HEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELOHEELO");
                                      setState(() {});

                                      (await uploadImageToFirebase(sentFile!,
                                          widget.roomID!, widget.userUID!));
                                      // await sendMessage(widget.roomID!,
                                      //     imageSentUrl, _auth.currentUser!.uid);
                                    },
                                    child: SizedBox(
                                        height: h * 0.052321429,
                                        width: w * 0.078309179,
                                        child: Center(
                                          child: Icon(
                                            Icons.send_outlined,
                                            size: h * 0.03,
                                            color: SystemColors
                                                .whiteBackgroundColor,
                                          ),
                                        )),
                                  ),
                                ],
                              ),
                            ),
                          )
                        ]),
                      )
                    : Positioned(
                        bottom: 0,
                        right: 0,
                        left: 0,
                        child: Container(
                          color: SystemColors.whiteBackgroundColor,
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: h * 0.009),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    showModalBottomSheet(
                                      shape: const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(16),
                                              topRight: Radius.circular(16))),
                                      context: context,
                                      builder: (BuildContext context) {
                                        return SizedBox(
                                          // color: Colors.red,
                                          height: h * 0.15,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              ListTile(
                                                leading:
                                                    const Icon(Icons.image),
                                                title:
                                                    const Text('Select image'),
                                                onTap: () async {
                                                  Navigator.pop(context);
                                                  if (await PermissionHandler
                                                      .askGalleryPermission()) {
                                                    ImageSelector
                                                        .selectImages();
                                                  }
                                                },
                                              ),
                                              ListTile(
                                                leading: const Icon(
                                                    Icons.location_on),
                                                title:
                                                    const Text('Send location'),
                                                onTap: () async {
                                                  Navigator.pop(context);
                                                  if (await PermissionHandler
                                                      .askLocationPermission()) {}
                                                },
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  child: SizedBox(
                                    width: w * 0.057971014,
                                    height: h * 0.026785714,
                                    child: const Icon(
                                      Icons.attach_file_outlined,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: w * 0.057971014,
                                  height: h * 0.026785714,
                                  child: InkWell(
                                    onTap: () async {
                                      if (await PermissionHandler
                                          .askCameraPermission()) {
                                        _imageFile =
                                            await ImageSelector.takePhoto();
                                        setState(() {});
                                      }
                                    },
                                    child: const Icon(
                                      Icons.camera_alt_outlined,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: w * 0.620772947,
                                  height: h * 0.055803571,
                                  decoration: BoxDecoration(
                                      // color: Colors.red,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(6)),
                                      border: Border.all(
                                          color:
                                              SystemColors.messageIsNotMeColor,
                                          width: 1)),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // color: Colors.red,
                                        height: h * 0.055803571,
                                        width: w * 0.568599034,
                                        child: TextField(
                                          textAlign: TextAlign.right,
                                          textInputAction:
                                              TextInputAction.newline,
                                          textDirection: TextDirection.rtl,
                                          maxLines: null,
                                          controller: messageController,
                                          decoration: InputDecoration(
                                            hintText: ' ...اكتب رسالتك هنا',
                                            contentPadding:
                                                EdgeInsets.symmetric(
                                              horizontal: w * 0.00,
                                              vertical: h * 0.01,
                                            ),
                                            border: InputBorder.none,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    if (messageController.text
                                        .trim()
                                        .isNotEmpty) {
                                      widget.roomID != " "
                                          ? sendMessage(
                                              widget.roomID!,
                                              messageController.text,
                                              _auth.currentUser!.uid,
                                              'text')
                                          : createChatRoom(
                                              _auth.currentUser!.uid,
                                              widget.userUID!,
                                              messageController.text,
                                              widget.username!,
                                              UserSharedPref.getUsername());

                                      setState(() {
                                        messageController.clear();
                                      });
                                    }
                                  },
                                  child: SizedBox(
                                      height: h * 0.022321429,
                                      width: w * 0.048309179,
                                      child: Icon(
                                        Icons.send_outlined,
                                        size: h * 0.03,
                                        color: SystemColors.mainColor,
                                      )),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
              ],
            ),
          );
        },
      ),
    );
  }
}
