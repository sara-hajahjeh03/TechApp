// ignore_for_file: unrelated_type_equality_checks, use_build_context_synchronously

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/PleaseWaitDialog.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/Widgets/text_field_widget.dart';

class editPasswordScreen extends StatefulWidget {
  editPasswordScreen({Key? key}) : super(key: key);

  @override
  State<editPasswordScreen> createState() => _editPasswordScreenState();
}

User? user = FirebaseAuth.instance.currentUser;
var _passwordFormKey = GlobalKey<FormState>();

final TextEditingController currentPasswordController = TextEditingController();
final TextEditingController newPasswordController = TextEditingController();
final TextEditingController confirmPasswordController = TextEditingController();

bool isCurrentPassword = true;
bool isNewPassword = true;
bool isConfirnPassword = true;

class _editPasswordScreenState extends State<editPasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Sizer(builder: (context, orientation, deviceType) {
        return Scaffold(
          backgroundColor: SystemColors.whiteBackgroundColor,
          body: SingleChildScrollView(
            child: Column(
              children: [
                AppBar_Widget(
                  titleText: 'تغيير كلمة السر',
                  appBarheight: SystemSize.appBarheight.h,
                ),
                SizedBox(
                  height: 15.64.h,
                ),
                Form(
                  key: _passwordFormKey,
                  child: Column(
                    children: [
                      TextField_Widget(
                        Text: 'كلمة السر الحالية',
                        fieldWidth: 92.27.w,
                        RegExp: r'^.{5,}$',
                        validateText: "يرجى ادخال اسم صحيح",
                        RegExpText: 'يرجى ادخال اكثر من 5 خانات للأسم',
                        isPassword: isCurrentPassword,
                        controller: currentPasswordController,
                        textSize: 16,
                        leftIcon: true,
                        preffixIcon: "assets/eye.png",
                        leftIconFunction: () {
                          setState(() {
                            isCurrentPassword = !isCurrentPassword;
                          });
                        },
                        textFieldColor: SystemColors.whiteBackgroundColor,
                        elevation: 1,
                      ),
                      SizedBox(
                        height: 3.79.h,
                      ),
                      TextField_Widget(
                        Text: "كلمة السر الجديدة",
                        fieldWidth: 92.27.w,
                        validateText: "يرجى ادخال عنوان بريد",
                        leftIcon: true,
                        preffixIcon: "assets/eye.png",
                        isPassword: isNewPassword,
                        leftIconFunction: () {
                          setState(() {
                            isNewPassword = !isNewPassword;
                          });
                        },
                        textSize: 16,
                        controller: newPasswordController,
                        textFieldColor: SystemColors.whiteBackgroundColor,
                        elevation: 1,
                      ),
                      SizedBox(
                        height: 3.79.h,
                      ),
                      TextField_Widget(
                        Text: "تأكيد كلمة السر الجديدة",
                        fieldWidth: 92.27.w,
                        validateText: "يرجى ادخال عنوان بريد",
                        inputAction: TextInputAction.next,
                        leftIcon: true,
                        isPassword: isConfirnPassword,
                        preffixIcon: "assets/eye.png",
                        leftIconFunction: () {
                          setState(() {
                            isConfirnPassword = !isConfirnPassword;
                          });
                        },
                        textSize: 16,
                        controller: confirmPasswordController,
                        textFieldColor: SystemColors.whiteBackgroundColor,
                        elevation: 1,
                      ),
                      SizedBox(
                        height: 3.79.h,
                      ),
                      Button_widget(
                        Function: () async {
                          showDialog(
                              context: context,
                              barrierDismissible: false,
                              builder: (
                                BuildContext context,
                              ) =>
                                  PleaseWaitWidget());
                          bool isCurrentPasswordValid =
                              await validateCurrentPassword(
                                  currentPasswordController.text);
                          if (isCurrentPasswordValid) {
                            await updatePassword(newPasswordController.text);
                          } else {
                            Fluttertoast.showToast(
                                msg: 'كلمة السر الحالية خطأ');
                          }
                          Navigator.of(context).pop();
                          confirmPasswordController.clear();
                          currentPasswordController.clear();
                          newPasswordController.clear();
                        },
                        buttonWidth: 92.27.w,
                        buttonText: 'تعديل',
                        activeButton1: true,
                        activeButtonColor: SystemColors.mainColor,
                        activeTextColor: SystemColors.whiteBackgroundColor,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  Future<bool> validateCurrentPassword(String password) async {
    return await validatePassword(password);
  }

  Future<bool> validatePassword(String password) async {
    var authCredentials =
        EmailAuthProvider.credential(email: user!.email!, password: password);
    try {
      var authResult =
          await user!.reauthenticateWithCredential(authCredentials);
      return authResult.user != null;
    } catch (e) {
      return false;
    }
  }

  Future<void> updatePassword(String password) async {
    if (confirmPasswordController.text == newPasswordController.text) {
      user!.updatePassword(password);
      Fluttertoast.showToast(msg: "تم تغيير كلمة السر");
    } else {
      Fluttertoast.showToast(msg: 'كلمة السر الجديدة غير متشابهة');
    }
  }
}
