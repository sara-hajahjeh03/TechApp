import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/ProviderScreens/signIn_Screen.dart';
import 'package:tech_app_v1/UserScreens/signIn_screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/Widgets/choiceButton_widget.dart';

class choice_Screen extends StatefulWidget {
  choice_Screen({Key? key}) : super(key: key);

  @override
  State<choice_Screen> createState() => _choice_ScreenState();
}

class _choice_ScreenState extends State<choice_Screen> {
  bool userCheck = false;
  bool providerCheck = false;

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return Scaffold(
        backgroundColor: SystemColors.whiteBackgroundColor,
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 8.h,
              ),
              SizedBox(
                height: 36.153.h,
                width: SystemSize.sizedBoxImageWidth.w,
                child: Image.asset(
                  "assets/Thinking face-rafiki 1.png",
                  fit: BoxFit.cover,
                ),
              ),
              Text(
                "اختار نوع الحساب واكمل عمليه\n                 تسجيل الدخول",
                style: SystemFont.mainFont20W700,
              ),
              SizedBox(
                height: 1.79.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 3.86.w, right: 3.86.w),
                child: Row(
                  children: [
                    InkWell(
                      radius: 100,
                      borderRadius: const BorderRadius.all(Radius.circular(16)),
                      onTap: () {
                        setState(() {
                          userCheck = false;
                          providerCheck = true;
                        });
                      },
                      child: ChoiceButton(
                        providerCheck: providerCheck,
                        boxHeight: 18.86.h,
                        boxWidth: 44.2.w,
                        iconPadding: 5.h,
                        iconOnPressed: () {},
                        paddingOnPressed: 2.h,
                        icon: 'assets/providerChoice.png',
                        text: 'مؤدي خدمة',
                      ),
                    ),
                    SizedBox(width: 3.86.w),
                    InkWell(
                      borderRadius: const BorderRadius.all(Radius.circular(16)),
                      radius: 100,
                      onTap: () {
                        setState(() {
                          providerCheck = false;
                          userCheck = true;
                        });
                      },
                      child: ChoiceButton(
                          userCheck: userCheck,
                          boxHeight: 18.86.h,
                          boxWidth: 44.2.w,
                          iconPadding: 5.h,
                          paddingOnPressed: 2.h,
                          icon: 'assets/userChoice.png',
                          text: 'مستخدم',
                          iconOnPressed: () {}),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 2.679.h),
              InkWell(
                onTap: () {
                  if (userCheck == true && providerCheck == false) {
                    Navigator.pushAndRemoveUntil(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation1, animation2) =>
                            const SignInScreen(),
                        transitionDuration: Duration.zero,
                        reverseTransitionDuration: Duration.zero,
                      ),
                      (route) =>
                          true, //if you want to disable back feature set to false
                    );
                  }
                  if (providerCheck == true && userCheck == false) {
                    Navigator.pushAndRemoveUntil(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation1, animation2) =>
                            const SignInScreenProvider(),
                        transitionDuration: Duration.zero,
                        reverseTransitionDuration: Duration.zero,
                      ),
                      (route) =>
                          true, //if you want to disable back feature set to false
                    );
                  }
                },
                child: Button_widget(
                  buttonWidth: 92.27.w,
                  buttonColor: SystemColors.whiteBackgroundColor,
                  borderColor: SystemColors.mainColor,
                  activeButtonColor: SystemColors.mainColor,
                  activeTextColor: SystemColors.whiteBackgroundColor,
                  inactiveTextColor: SystemColors.mainColor,
                  activeButton1: userCheck,
                  activeButton2: providerCheck,
                  buttonText: "التالي",
                  textColor: SystemColors.mainColor,
                ),
              ),
              SizedBox(
                height: 1.786.h,
              ),
              Button_widget(
                  buttonWidth: 92.27.w,
                  activeButton1: true,
                  buttonColor: SystemColors.mainColor,
                  activeTextColor: SystemColors.whiteBackgroundColor,
                  activeButtonColor: SystemColors.mainColor,
                  buttonText: "تسجبل دخول كزائر"),
              SizedBox(
                height: 2.795.h,
              ),
              Text(
                "لديك حساب؟",
                style: SystemFont.mainFont14W400,
              ),
              SizedBox(
                height: 1.786.h,
              ),
              InkWell(
                onTap: () {},
                child: Text(
                  "سجل دخول",
                  style: SystemFont.mainFont14W400Blue,
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
