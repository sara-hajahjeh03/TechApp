// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/SharedScreens/choice_Screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/services/userServices.dart';

class IntroScreen extends StatelessWidget {
  const IntroScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return Scaffold(
        body: IntroductionScreen(
          initialPage: 0,
          globalBackgroundColor: SystemColors.whiteBackgroundColor,
          globalHeader: Padding(
            padding: EdgeInsets.only(right: 3.86.h),
            child: Container(
              height: 10.152.h,
              color: SystemColors.whiteBackgroundColor,
              child: Align(
                alignment: Alignment.bottomRight,
                child: InkWell(
                  onTap: () async {
                    UserSharedPref.setIntroScreen(false);
                    Navigator.pushAndRemoveUntil(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation1, animation2) =>
                            choice_Screen(),
                        transitionDuration: Duration.zero,
                        reverseTransitionDuration: Duration.zero,
                      ),
                      (route) =>
                          false, //if you want to disable back feature set to false
                    );
                  },
                  child: Text("تخطى",
                      style: GoogleFonts.tajawal(
                          fontSize: SystemSize.smallTextSize,
                          color: SystemColors.mainColor)),
                ),
              ),
            ),
          ),
          pages: [
            PageViewModel(
                title: 'مرحبا بك',
                body:
                    'تستطيع طلب اى خدمه تريدها من \n خلال مزودى الخدمه خاصتنا',
                image: Center(
                  child: SizedBox(
                    height: SystemSize.sizedBoxImageHeight.h,
                    width: SystemSize.sizedBoxImageWidth.w,
                    child: Image.asset('assets/Electrician-rafiki 1.png',
                        fit: BoxFit.cover),
                  ),
                ),
                decoration: PageDecoration(
                    imageFlex: 0,
                    imagePadding: EdgeInsets.only(top: 16.629.h),
                    titlePadding: EdgeInsets.only(top: 2.67.h),
                    bodyPadding: EdgeInsets.only(top: 2.23.h),
                    bodyTextStyle: GoogleFonts.almarai(
                        fontSize: SystemSize.mediumTextSize,
                        fontWeight: FontWeight.w400,
                        color: SystemColors.textColorBlack,
                        wordSpacing: 1),
                    titleTextStyle: GoogleFonts.almarai(
                        fontSize: SystemSize.bigTextSize,
                        fontWeight: FontWeight.w700,
                        color: SystemColors.textColorBlack))),
            PageViewModel(
                title: 'مرحبا بك',
                body:
                    'تستطيع طلب اى خدمه تريدها من \n خلال مزودى الخدمه خاصتنا',
                image: Center(
                  child: SizedBox(
                    height: SystemSize.sizedBoxImageHeight.h,
                    width: SystemSize.sizedBoxImageWidth.w,
                    child: Image.asset('assets/Car wash-rafiki 1.png',
                        fit: BoxFit.cover),
                  ),
                ),
                decoration: PageDecoration(
                    imageFlex: 0,
                    imagePadding: EdgeInsets.only(top: 16.629.h),
                    titlePadding: EdgeInsets.only(top: 2.67.h),
                    bodyPadding: EdgeInsets.only(top: 2.23.h),
                    bodyTextStyle: GoogleFonts.almarai(
                        fontSize: SystemSize.mediumTextSize,
                        fontWeight: FontWeight.w400,
                        color: SystemColors.textColorBlack,
                        wordSpacing: 1),
                    titleTextStyle: GoogleFonts.almarai(
                        fontSize: SystemSize.bigTextSize,
                        fontWeight: FontWeight.w700,
                        color: SystemColors.textColorBlack))),
            PageViewModel(
                title: 'مرحبا بك',
                body:
                    'تستطيع طلب اى خدمه تريدها من \n خلال مزودى الخدمه خاصتنا',
                image: Center(
                  child: SizedBox(
                    height: SystemSize.sizedBoxImageHeight.h,
                    width: SystemSize.sizedBoxImageWidth.w,
                    child: Image.asset('assets/Service 24_7-rafiki 1.png',
                        fit: BoxFit.cover),
                  ),
                ),
                decoration: PageDecoration(
                    imageFlex: 0,
                    imagePadding: EdgeInsets.only(top: 16.629.h),
                    titlePadding: EdgeInsets.only(top: 2.67.h),
                    bodyPadding: EdgeInsets.only(top: 2.23.h),
                    bodyTextStyle: GoogleFonts.almarai(
                        fontSize: SystemSize.mediumTextSize,
                        fontWeight: FontWeight.w400,
                        color: SystemColors.textColorBlack,
                        wordSpacing: 1),
                    titleTextStyle: GoogleFonts.almarai(
                        fontSize: SystemSize.bigTextSize,
                        fontWeight: FontWeight.w700,
                        color: SystemColors.textColorBlack))),
          ],
          dotsDecorator: const DotsDecorator(
            size: Size(10, 10),
            color: SystemColors.greyColor,
            activeSize: Size.square(15),
            activeColor: SystemColors.mainColor,
          ),
          showDoneButton: true,
          done: Text("ابدأ الان",
              style: GoogleFonts.tajawal(
                  fontSize: SystemSize.smallTextSize,
                  color: SystemColors.mainColor)),
          showNextButton: true,
          next: Text("التالي",
              style: GoogleFonts.tajawal(
                  fontSize: SystemSize.smallTextSize,
                  color: SystemColors.mainColor)),
          onDone: () => onDone(context),
          curve: Curves.ease,
        ),
      );
    });
  }

  void onDone(context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('ON_BOARDING', false);
    Navigator.pushAndRemoveUntil(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation1, animation2) => choice_Screen(),
        transitionDuration: Duration.zero,
        reverseTransitionDuration: Duration.zero,
      ),
      (route) => false, //if you want to disable back feature set to false
    );
  }
}
