import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/ProviderScreens/sentForReview.dart';
import 'package:tech_app_v1/ProviderScreens/signIn_Screen.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/Widgets/dropdown.dart';
import 'package:tech_app_v1/Widgets/text_field_widget.dart';
import 'package:tech_app_v1/providerModel/provider_models.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';

class SignUpScreenProvider extends StatefulWidget {
  const SignUpScreenProvider({Key? key}) : super(key: key);

  @override
  State<SignUpScreenProvider> createState() => _SignUpScreenProviderState();
}

class _SignUpScreenProviderState extends State<SignUpScreenProvider> {
  bool createAcountButton = true;
  bool signInButton = false;
  final _auth = FirebaseAuth.instance;

  // string for displaying the error Message
  String? errorMessage;

  // our form key
  final _formKey = GlobalKey<FormState>();

  //  Controller
  final fullNameEditingController = TextEditingController();
  final secondnameEditingController = TextEditingController();
  final emailEditingController = TextEditingController();
  final passwordEditingController = TextEditingController();
  final confirmPasswordEditingController = TextEditingController();
  final aboutEditingController = TextEditingController();
  final phoneNumberController = TextEditingController();
  final idNumber = TextEditingController();
  final locationEditingController = TextEditingController();

  String? subscriptionEdittingController;
  String? cityEditingController;
  String? occupationEdittingController;
  String? profilePicController = "";
  var selectedService, subscriptionType;

  String? picController = "";

  //For Image Upload and Image Crop
  XFile? _pickedImage;

// Post Images and Videos*************************************************************************************************//
  Future<void> uploadPics() async {
    final image = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (image != null) {
      setState(() {
        _pickedImage = image;
      });
    }
    Reference ref = FirebaseStorage.instance
        .ref()
        .child('User_ProfilePics/${DateTime.now()}.png');

    await ref.putFile(File(_pickedImage!.path));

    ref.getDownloadURL().then((value) async {
      setState(() {
        picController = value;
      });
    });
  }
  //*********************************************************************************************************************//

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Sizer(builder: (context, orientation, deviceType) {
      return GestureDetector(
        onTap: () {
          FocusManager.instance.primaryFocus?.unfocus();
        },
        child: Scaffold(
            backgroundColor: SystemColors.whiteBackgroundColor,
            body: Stack(
              children: [
                Container(
                  height: 100.h,
                  decoration: const BoxDecoration(
                    color: SystemColors.whiteBackgroundColor,
                    image: DecorationImage(
                        image: AssetImage(
                          'assets/bg (2).png',
                        ),
                        fit: BoxFit.cover),
                  ),
                  child: SingleChildScrollView(
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          AppBar_Widget(
                            rightIcon: "assets/backArrow.png",
                            titleText: "انشاء حساب",
                            appBarheight: SystemSize.appBarheight.h,
                          ),
                          SizedBox(
                            height: 8.817.h,
                          ),
                          Container(
                            width: 92.27.w,
                            height: 79.688.h,
                            decoration: const BoxDecoration(
                                color: SystemColors.whiteBackgroundColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(8))),
                            child: SingleChildScrollView(
                              child: Column(children: [
                                SizedBox(
                                  height: 5.357.h,
                                ),
                                Container(
                                  width: SystemSize.textField_width.w,
                                  height: h * SystemSize.textField_Height,
                                  decoration: const BoxDecoration(
                                      color: SystemColors.lightGrey,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(8))),
                                  child: Row(
                                    children: [
                                      InkWell(
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(16)),
                                          radius: 100,
                                          onTap: () {
                                            Navigator.pushReplacement(
                                              context,
                                              PageRouteBuilder(
                                                pageBuilder: (context,
                                                        animation1,
                                                        animation2) =>
                                                    const SignInScreenProvider(),
                                                transitionDuration:
                                                    Duration.zero,
                                                reverseTransitionDuration:
                                                    Duration.zero,
                                              ),
                                            );
                                            FocusManager.instance.primaryFocus
                                                ?.unfocus();
                                            setState(() {
                                              signInButton = true;
                                              createAcountButton = false;
                                            });
                                          },
                                          child: Button_widget(
                                              activeButton2: signInButton,
                                              activeButtonColor:
                                                  SystemColors.mainColor,
                                              inactiveButtonColor:
                                                  SystemColors.lightGrey,
                                              activeTextColor:
                                                  SystemColors.whiteBackgroundColor,
                                              inactiveTextColor: SystemColors
                                                  .inactiveTextColor,
                                              buttonWidth: 42.27.w,
                                              buttonColor:
                                                  SystemColors.mainColor,
                                              buttonText: "تسجيل الدخول")),
                                      InkWell(
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(16)),
                                          radius: 100,
                                          onTap: () {
                                            FocusManager.instance.primaryFocus
                                                ?.unfocus();

                                            setState(() {
                                              signInButton = false;
                                              createAcountButton = true;
                                            });
                                          },
                                          child: Button_widget(
                                              activeButton1: createAcountButton,
                                              activeButtonColor:
                                                  SystemColors.mainColor,
                                              inactiveButtonColor:
                                                  SystemColors.lightGrey,
                                              activeTextColor:
                                                  SystemColors.whiteBackgroundColor,
                                              inactiveTextColor: SystemColors
                                                  .inactiveTextColor,
                                              buttonWidth: 42.27.w,
                                              buttonColor:
                                                  SystemColors.mainColor,
                                              buttonText: "انشاء حساب")),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                TextField_Widget(
                                  preffixIcon: 'assets/Property 1=Users.png',
                                  Text: 'الأسم بالكامل',
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  controller: fullNameEditingController,
                                  keyboardType: TextInputType.name,
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                TextField_Widget(
                                  preffixIcon: 'assets/icons.png',
                                  Text: 'البريد الالكتروني',
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  controller: emailEditingController,
                                  keyboardType: TextInputType.emailAddress,
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                TextField_Widget(
                                  preffixIcon: 'assets/Property 1=Users.png',
                                  Text: 'رقم الهاتف',
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  controller: phoneNumberController,
                                  keyboardType: TextInputType.phone,
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                DropDown_Widget_FromFireBase(
                                  hintText: "المدينة",
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  SizedboxWidth: 67.w,
                                  editingController: cityEditingController,
                                  itemsCollection: 'cities',
                                  selectedItem: selectedService,
                                  valueChanged: (value) {
                                    setState(() {
                                      cityEditingController = value;
                                    });
                                  },
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                TextField_Widget(
                                  preffixIcon: 'assets/Property 1=Users.png',
                                  Text: 'اسم المنطقة',
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  controller: locationEditingController,
                                  keyboardType: TextInputType.streetAddress,
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                TextField_Widget(
                                  preffixIcon: 'assets/icons.png',
                                  Text: 'الرقم الوطني',
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  controller: idNumber,
                                  keyboardType: TextInputType.number,
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                DropDown_Widget_FromFireBase(
                                  hintText: "المهنة",
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  SizedboxWidth: 67.w,
                                  editingController:
                                      occupationEdittingController,
                                  itemsCollection: 'occupation',
                                  selectedItem: selectedService,
                                  valueChanged: (value) {
                                    setState(() {
                                      occupationEdittingController = value;
                                    });
                                  },
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                DropDown_Widget_FromFireBase(
                                  hintText: "نوع الاشتراك",
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  SizedboxWidth: 67.w,
                                  editingController:
                                      subscriptionEdittingController,
                                  itemsCollection: 'subscriptionType',
                                  selectedItem: subscriptionType,
                                  valueChanged: (value) {
                                    setState(() {
                                      subscriptionEdittingController = value;
                                    });
                                  },
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                TextField_Widget(
                                  preffixIcon: 'assets/eye.png',
                                  Text: 'كلمة المرور',
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  controller: passwordEditingController,
                                  isPassword: true,
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                TextField_Widget(
                                  preffixIcon: 'assets/eye.png',
                                  Text: 'تأكيد كلمة المرور',
                                  fieldWidth: SystemSize.textField_width.w,
                                  textSize: 14,
                                  controller: confirmPasswordEditingController,
                                  isPassword: true,
                                  inputAction: TextInputAction.done,
                                ),
                                SizedBox(
                                  height: 1.786.h,
                                ),
                                InkWell(
                                  onTap: () {
                                    signUpProvider(emailEditingController.text,
                                        passwordEditingController.text);
                                  },
                                  child: Button_widget(
                                    buttonWidth: SystemSize.textField_width.w,
                                    activeButtonColor: SystemColors.mainColor,
                                    activeButton1: true,
                                    buttonText: "انشاء حساب",
                                    textSize: 16,
                                    activeTextColor: SystemColors.whiteBackgroundColor,
                                  ),
                                ),
                                SizedBox(
                                  height: 3.576.h,
                                ),
                              ]),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            )),
      );
    });
  }

  void signUpProvider(String email, String password) async {
    if (_formKey.currentState!.validate()) {
      try {
        await _auth
            .createUserWithEmailAndPassword(email: email, password: password)
            .then((value) => {postDetailsToFirestore()})
            .catchError((e) {
          Fluttertoast.showToast(msg: e!.message);
        });
      } on FirebaseAuthException catch (error) {
        switch (error.code) {
          case "invalid-email":
            errorMessage = "Your email address appears to be malformed.";
            break;
          case "wrong-password":
            errorMessage = "Your password is wrong.";
            break;
          case "user-not-found":
            errorMessage = "User with this email doesn't exist.";
            break;
          case "user-disabled":
            errorMessage = "User with this email has been disabled.";
            break;
          case "too-many-requests":
            errorMessage = "Too many requests";
            break;
          case "operation-not-allowed":
            errorMessage = "Signing in with Email and Password is not enabled.";
            break;
          default:
            errorMessage = "An undefined Error happened.";
        }
        Fluttertoast.showToast(msg: errorMessage!);
      }
    }
  }

  postDetailsToFirestore() async {
    // calling our firestore
    // calling our user model
    // sedning these values
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    User? user = _auth.currentUser;

    UserModelProvider userModel = UserModelProvider();

    // writing all the values
    userModel.email = user!.email;
    userModel.uid = user.uid;
    userModel.FullName = fullNameEditingController.text;
    userModel.idNumber = idNumber.text;
    userModel.Occupation = occupationEdittingController;
    userModel.location = locationEditingController.text;
    userModel.city = cityEditingController;
    userModel.subscriptionType = subscriptionEdittingController;
    userModel.About = aboutEditingController.text;
    userModel.profilePic = profilePicController;
    userModel.phoneNumber = phoneNumberController.text;

    await firebaseFirestore
        .collection("Admin_Approval_Provider_SignUp")
        .doc(user.uid)
        .set(userModel.toMap());

    Navigator.pushAndRemoveUntil(
        (context),
        MaterialPageRoute(builder: (context) => sentForReview()),
        (route) => false);
  }
}
