import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/ProviderScreens/signUp_Screen.dart';
import 'package:tech_app_v1/UserScreens/home_Screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';
import 'package:tech_app_v1/Widgets/button_Widget.dart';
import 'package:tech_app_v1/Widgets/text_field_widget.dart';
import 'package:tech_app_v1/adminPanel/Screens/AdminPanelHome.dart';
import 'package:tech_app_v1/adminPanel/Screens/AdminPanelProviderSignUp.dart';

class SignInScreenProvider extends StatefulWidget {
  const SignInScreenProvider({Key? key}) : super(key: key);

  @override
  State<SignInScreenProvider> createState() => _SignInScreenProviderState();
}

class _SignInScreenProviderState extends State<SignInScreenProvider> {
  bool createAcountButton = false;
  bool signInButton = true;
  final _formKey = GlobalKey<FormState>();
  final _auth = FirebaseAuth.instance;
  // string for displaying the error Message
  String? errorMessage;
  //Controllers
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Sizer(builder: (context, orientation, deviceType) {
      return GestureDetector(
        onTap: () {
          FocusManager.instance.primaryFocus?.unfocus();
        },
        child: Scaffold(
            backgroundColor: SystemColors.whiteBackgroundColor,
            body: Stack(
              children: [
                Container(
                  height: 100.h,
                  decoration: const BoxDecoration(
                    color: SystemColors.whiteBackgroundColor,
                    image: DecorationImage(
                        image: AssetImage(
                          'assets/bg (2).png',
                        ),
                        fit: BoxFit.cover),
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        AppBar_Widget(
                          rightIcon: "assets/backArrow.png",
                          titleText: "تسجيل الدخول",
                          appBarheight: SystemSize.appBarheight.h,
                        ),
                        SizedBox(
                          height: 8.817.h,
                        ),
                        Container(
                          width: 92.27.w,
                          height: 70.424.h,
                          decoration: const BoxDecoration(
                              color: SystemColors.whiteBackgroundColor,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(8))),
                          child: Form(
                            key: _formKey,
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  SizedBox(
                                    height: 5.357.h,
                                  ),
                                  Container(
                                    width: SystemSize.textField_width.w,
                                    height: h * SystemSize.textField_Height,
                                    decoration: const BoxDecoration(
                                        color: SystemColors.lightGrey,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(8))),
                                    child: Row(
                                      children: [
                                        InkWell(
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(16)),
                                            radius: 100,
                                            onTap: () {
                                              FocusManager.instance.primaryFocus
                                                  ?.unfocus();
                                              setState(() {
                                                signInButton = true;
                                                createAcountButton = false;
                                              });
                                            },
                                            child: Button_widget(
                                                activeButton2: signInButton,
                                                activeButtonColor:
                                                    SystemColors.mainColor,
                                                inactiveButtonColor:
                                                    SystemColors.lightGrey,
                                                activeTextColor:
                                                    SystemColors.whiteBackgroundColor,
                                                inactiveTextColor: SystemColors
                                                    .inactiveTextColor,
                                                buttonWidth: 42.27.w,
                                                buttonColor:
                                                    SystemColors.mainColor,
                                                buttonText: "تسجيل الدخول")),
                                        InkWell(
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(16)),
                                            radius: 100,
                                            onTap: () {
                                              Navigator.pushReplacement(
                                                context,
                                                PageRouteBuilder(
                                                  pageBuilder: (context,
                                                          animation1,
                                                          animation2) =>
                                                      const SignUpScreenProvider(),
                                                  transitionDuration:
                                                      Duration.zero,
                                                  reverseTransitionDuration:
                                                      Duration.zero,
                                                ),
                                              );
                                              FocusManager.instance.primaryFocus
                                                  ?.unfocus();

                                              setState(() {
                                                signInButton = false;
                                                createAcountButton = true;
                                              });
                                            },
                                            child: Button_widget(
                                                activeButton1:
                                                    createAcountButton,
                                                activeButtonColor:
                                                    SystemColors.mainColor,
                                                inactiveButtonColor:
                                                    SystemColors.lightGrey,
                                                activeTextColor:
                                                    SystemColors.whiteBackgroundColor,
                                                inactiveTextColor: SystemColors
                                                    .inactiveTextColor,
                                                buttonWidth: 42.27.w,
                                                buttonColor:
                                                    SystemColors.mainColor,
                                                buttonText: "انشاء حساب")),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 3.013.h,
                                  ),
                                  TextField_Widget(
                                    preffixIcon: 'assets/icons.png',
                                    Text: 'البريد الالكتروني',
                                    fieldWidth: SystemSize.textField_width.w,
                                    keyboardType: TextInputType.emailAddress,
                                    textSize: 14,
                                    controller: emailController,
                                    maxHeight: 9.6.h,
                                  ),
                                  SizedBox(
                                    height: 1.786.h,
                                  ),
                                  TextField_Widget(
                                      preffixIcon: 'assets/eye.png',
                                      Text: 'كلمة المرور',
                                      isPassword: true,
                                      fieldWidth: SystemSize.textField_width.w,
                                      textSize: 14,
                                      controller: passwordController,
                                      inputAction: TextInputAction.done,
                                      maxHeight: 20.h),
                                  SizedBox(
                                    height: 2.679.h,
                                  ),
                                  InkWell(
                                    onTap: () async {
                                      signIn(emailController.text,
                                          passwordController.text);
                                    },
                                    child: Button_widget(
                                      buttonWidth: SystemSize.textField_width.w,
                                      activeButtonColor: SystemColors.mainColor,
                                      activeButton1: true,
                                      buttonText: "تسجيل الدخول",
                                      textSize: 16,
                                      activeTextColor: SystemColors.whiteBackgroundColor,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 4.576.h,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      SizedBox(
                                        width: 20.77.w,
                                        child: const Divider(
                                          thickness: 1,
                                          color: Color(0xFFE7E7E7),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 3.865.w,
                                      ),
                                      Text(
                                        'او سجل الدخول باستخدام',
                                        style: SystemFont.mainFont14W400,
                                      ),
                                      SizedBox(
                                        height: 3.865.w,
                                      ),
                                      SizedBox(
                                        width: 20.77.w,
                                        child: const Divider(
                                          thickness: 1,
                                          color: Color(0xFFE7E7E7),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 2.679.h,
                                  ),
                                  Button_widget(
                                      buttonWidth: SystemSize.textField_width.w,
                                      activeButton1: true,
                                      activeButtonColor: Colors.white,
                                      borderColor: SystemColors.greyColor,
                                      textFontWeight: FontWeight.bold,
                                      activeTextColor: Colors.grey.shade700,
                                      isImageGoogle: true,
                                      iconSizedBox: 3.864.w,
                                      buttonText: "Google"),
                                  SizedBox(
                                    height: 1.786.h,
                                  ),
                                  Button_widget(
                                      buttonWidth: SystemSize.textField_width.w,
                                      activeButton1: true,
                                      activeButtonColor: Colors.white,
                                      borderColor: SystemColors.greyColor,
                                      textFontWeight: FontWeight.bold,
                                      activeTextColor: Colors.grey.shade700,
                                      isImageFacebook: true,
                                      facebookSizedbox: 3.w,
                                      iconSizedBox: 3.064.w,
                                      buttonText: "Facebook")
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            )),
      );
    });
  }

  void signIn(String email, String password) async {
    if (_formKey.currentState!.validate()) {
      try {
        await _auth
            .signInWithEmailAndPassword(email: email, password: password)
            .then((uid) => {
                  Fluttertoast.showToast(msg: "Login Successful"),
                  Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (context) => home_Screen())),
                });
      } on FirebaseAuthException catch (error) {
        switch (error.code) {
          case "invalid-email":
            errorMessage = "Your email address appears to be malformed.";

            break;
          case "wrong-password":
            errorMessage = "Your password is wrong.";
            break;
          case "user-not-found":
            errorMessage = "User with this email doesn't exist.";
            break;
          case "user-disabled":
            errorMessage = "User with this email has been disabled.";
            break;
          case "too-many-requests":
            errorMessage = "Too many requests";
            break;
          case "operation-not-allowed":
            errorMessage = "Signing in with Email and Password is not enabled.";
            break;
          default:
            errorMessage = "An undefined Error happened.";
        }
        await FirebaseFirestore.instance
            .collection("Admin")
            .doc("adminLogin")
            .snapshots()
            .forEach((element) {
          if (element.data()?['adminEmail'] == emailController.text &&
              element.data()?['adminPassword'] == passwordController.text) {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => AdminPanelHome()),
                (route) => false);
          }
        }).catchError((e) {});
        Fluttertoast.showToast(msg: errorMessage!);
      }
    }
  }
}
