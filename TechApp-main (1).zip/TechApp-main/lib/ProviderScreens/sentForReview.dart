import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:tech_app_v1/SharedScreens/choice_Screen.dart';
import 'package:tech_app_v1/Utilities/Constants.dart';
import 'package:tech_app_v1/Widgets/appBar_Widget.dart';

class sentForReview extends StatelessWidget {
  const sentForReview({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return Scaffold(
        body: Stack(
          children: [
            Container(
              height: 100.h,
              decoration: const BoxDecoration(
                color: SystemColors.whiteBackgroundColor,
                image: DecorationImage(
                    image: AssetImage(
                      'assets/bg (2).png',
                    ),
                    fit: BoxFit.cover),
              ),
              child: Column(
                children: [
                  AppBar_Widget(
                    rightIcon: 'assets/backArrow.png',
                    titleText: 'انشاء حساب',
                    appBarheight: SystemSize.appBarheight.h,
                    navigateTo: choice_Screen(),
                  ),
                  SizedBox(height: 6.47.h),
                  Stack(
                    children: [
                      Center(
                        child: Container(
                          decoration: const BoxDecoration(
                              color: SystemColors.whiteBackgroundColor,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15))),
                          margin: EdgeInsets.only(top: 13.06.h),
                          height: 43.41.h,
                          width: 92.27.w,
                        ),
                      ),
                      Column(
                        children: [
                          SizedBox(
                              height: 46.21.h,
                              width: 100.w,
                              child: Image.asset('assets/Done-rafiki 1.png')),
                          Text(
                            'اكتملت عمليه انشاء الحساب بنجاح\n سوف يتم مراجعه بياناتك من خلال الادمن\n وسيتم الرجوع اليك فى اقرب وقت',
                            style: GoogleFonts.tajawal(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                color: SystemColors.textColorBlack),
                            textAlign: TextAlign.center,
                          )
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      );
    });
  }
}
