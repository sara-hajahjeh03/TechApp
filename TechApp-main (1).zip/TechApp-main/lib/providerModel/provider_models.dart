// ignore_for_file: non_constant_identifier_names

class UserModelProvider {
  String? uid;
  String? idNumber;
  String? email;
  String? FullName;
  String? Occupation;
  String? city;
  String? About;
  String? profilePic;
  String? phoneNumber;
  String? location;
  String? subscriptionType;

  UserModelProvider({
    this.uid,
    this.email,
    this.idNumber,
    this.FullName,
    this.Occupation,
    this.city,
    this.About,
    this.profilePic,
    this.phoneNumber,
    this.location,
    this.subscriptionType,
  });
//reciving data from server
  factory UserModelProvider.fromMap(map) {
    return UserModelProvider(
      uid: map['uid'],
      email: map['email'],
      idNumber: map['idNumber'],
      FullName: map['FullName'],
      Occupation: map['Occupation'],
      city: map['City'],
      About: map['About'],
      profilePic: map['profilePic'],
      phoneNumber: map['phoneNumber'],
      location: map['location'],
      subscriptionType: map['subscriptionType'],
    );
  }

// sending data to our server
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'idNumber': idNumber,
      'FullName': FullName,
      'Occupation': Occupation,
      'City': city,
      'About': About,
      'profilePic': profilePic,
      'phoneNumber': phoneNumber,
      'location': location,
      'subscriptionType': subscriptionType
    };
  }
}
